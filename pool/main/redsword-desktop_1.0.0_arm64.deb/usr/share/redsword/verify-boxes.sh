#!/bin/bash
# Verify the RedSword box system on the booted product. Run as root:
#   /usr/share/redsword/verify-boxes.sh
pass=0; fail=0
ck(){ local n=$1; shift; if "$@" >/dev/null 2>&1; then echo "PASS  $n"; pass=$((pass+1)); else echo "FAIL  $n"; fail=$((fail+1)); fi; }

echo "== RedSword box system check =="
echo "system: $(. /etc/os-release; echo "$PRETTY_NAME")"

ck "redsword command installed"            test -x /usr/bin/redsword
ck "container runtime present"             test -x /usr/bin/systemd-nspawn
ck "bundled debian base image present"     test -f /usr/share/redsword/bases/debian.tar.zst
ck "bundled signing keys present"          test -f /usr/share/redsword/keys/debian.gpg

echo ">> creating the Debian box from the bundled base (offline)"
redsword box create debian >/tmp/boxcreate.log 2>&1
ck "Debian box created from bundle"        grep -q "ready at" /tmp/boxcreate.log
ck "box registered on disk"                test -f /var/lib/redsword/boxes/debian/etc/os-release

echo ">> starting the warm box"
systemctl start redsword-box@debian 2>/dev/null
for _ in $(seq 1 40); do machinectl show redsword-debian -p Leader >/dev/null 2>&1 && break; sleep 0.25; done
ck "box runs as a registered machine"      machinectl show redsword-debian -p Leader
ck "command runs inside the box"           redsword run --from debian true
ck "box has its own Debian userland"       bash -c 'redsword run --from debian cat /etc/os-release 2>/dev/null | grep -q "ID=debian"'

echo ">> apt install from inside the box (needs network; tolerated if offline)"
if redsword install --from debian hello >/tmp/aptinst.log 2>&1; then
    ck "apt install works inside the box (Milestone B)" redsword run --from debian hello
    ck "installed CLI tool works directly on the host (Phase 3)" bash -c 'PATH=/usr/local/bin:$PATH hello'
else
    echo "SKIP  apt install + CLI bridge (no network in this boot)"
fi

echo ">> redsword doctor"
redsword doctor || true

echo
echo "passed: $pass  failed: $fail"
[ "$fail" -eq 0 ] && echo "REDSWORD BOX SYSTEM: OK" || echo "REDSWORD BOX SYSTEM: PROBLEMS"
[ "$fail" -eq 0 ]
