#!/usr/bin/env python3
# RedSword notification daemon + Notification Center.
#  * Implements org.freedesktop.Notifications: shows macOS-style popups (top-right),
#    handles click/actions.
#  * PERMANENTLY logs every notification (with date+time) to an append-only store;
#    the Notification Center shows the full history and nothing can be removed.
#  * SIGUSR1 toggles the Notification Center panel.
import os
import json
import signal
import subprocess
from datetime import datetime, date
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib, Gio, GdkPixbuf  # noqa: E402

BUS = "org.freedesktop.Notifications"
OBJ = "/org/freedesktop/Notifications"
XML = """<node><interface name="org.freedesktop.Notifications">
 <method name="Notify">
  <arg type="s" direction="in"/><arg type="u" direction="in"/><arg type="s" direction="in"/>
  <arg type="s" direction="in"/><arg type="s" direction="in"/><arg type="as" direction="in"/>
  <arg type="a{sv}" direction="in"/><arg type="i" direction="in"/><arg type="u" direction="out"/>
 </method>
 <method name="CloseNotification"><arg type="u" direction="in"/></method>
 <method name="GetCapabilities"><arg type="as" direction="out"/></method>
 <method name="GetServerInformation">
  <arg type="s" direction="out"/><arg type="s" direction="out"/>
  <arg type="s" direction="out"/><arg type="s" direction="out"/>
 </method>
 <signal name="NotificationClosed"><arg type="u"/><arg type="u"/></signal>
 <signal name="ActionInvoked"><arg type="u"/><arg type="s"/></signal>
</interface></node>"""

STORE_DIR = os.path.expanduser("~/.local/share/redsword")
STORE = os.path.join(STORE_DIR, "notifications.jsonl")
BAR_H = 30

CSS = b"""
.npop { background-color: rgba(28,28,30,0.98); border-radius: 14px; }
.npop .app { color: #93a8a0; font-size: 10px; font-weight: 700; letter-spacing: .6px; }
.npop .sum { color: #ffffff; font-size: 13px; font-weight: 700; }
.npop .body { color: #d6e6df; font-size: 12px; }
.npop .time { color: #63756e; font-size: 10px; }
.ncenter { background-color: rgba(18,18,20,0.98); }
.ncenter .title { color: #ffffff; font-size: 17px; font-weight: 800; margin: 14px 16px 2px; }
.ncenter .datehdr { color: #93a8a0; font-size: 11px; font-weight: 800; letter-spacing: .8px;
                    margin: 12px 18px 4px; }
.ncard { background-color: rgba(255,255,255,0.05); border-radius: 12px; margin: 4px 12px; }
.ncard:hover { background-color: rgba(255,255,255,0.09); }
.ncard .sum { color: #ffffff; font-size: 13px; font-weight: 700; }
.ncard .body { color: #b9ccc4; font-size: 12px; }
.ncard .app { color: #93a8a0; font-size: 10px; font-weight: 700; }
.ncard .time { color: #63756e; font-size: 10px; }
.ncenter .empty { color: #63756e; font-size: 13px; margin: 40px; }
"""


class Notifyd:
    def __init__(self):
        os.makedirs(STORE_DIR, exist_ok=True)
        self.history = self._load()
        self.next_id = (max([r["id"] for r in self.history], default=0) + 1)
        self.popups = []           # list of (id, window)
        self.center = None
        self.conn = None
        Gio.bus_own_name(
            Gio.BusType.SESSION, BUS,
            Gio.BusNameOwnerFlags.REPLACE | Gio.BusNameOwnerFlags.ALLOW_REPLACEMENT,
            self._acquired, None, lambda *a: None)
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGUSR1,
                             self._toggle_center, None)

    # ---------- persistence ----------
    def _load(self):
        out = []
        try:
            with open(STORE, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        out.append(json.loads(line))
        except Exception:
            pass
        return out

    def _persist(self, rec):
        try:
            with open(STORE, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception:
            pass

    # ---------- dbus ----------
    def _acquired(self, conn, name):
        self.conn = conn
        node = Gio.DBusNodeInfo.new_for_xml(XML)
        conn.register_object(OBJ, node.interfaces[0], self._method, None, None)

    def _method(self, conn, sender, path, iface, method, params, inv):
        if method == "Notify":
            app, replaces, icon, summary, body, actions, hints, timeout = params.unpack()
            nid = replaces if replaces else self.next_id
            if not replaces:
                self.next_id += 1
            rec = {
                "id": nid, "app": app or "Notification", "icon": icon or "",
                "summary": summary or "", "body": body or "",
                "actions": list(actions),
                "desktop": str(hints.get("desktop-entry", "")),
                "urgency": int(hints.get("urgency", 1)),
                "time": datetime.now().isoformat(timespec="seconds"),
            }
            self.history.append(rec)
            self._persist(rec)
            self._show_popup(rec, timeout)
            if self.center and self.center.get_visible():
                self._fill_center()
            inv.return_value(GLib.Variant("(u)", (nid,)))
        elif method == "GetCapabilities":
            inv.return_value(GLib.Variant(
                "(as)", (["body", "actions", "icon-static", "persistence"],)))
        elif method == "GetServerInformation":
            inv.return_value(GLib.Variant(
                "(ssss)", ("RedSword", "RedSword", "1.0", "1.2")))
        elif method == "CloseNotification":
            (cid,) = params.unpack()
            self._close_popup(cid, 3)
            inv.return_value(None)
        else:
            inv.return_value(None)

    def _emit(self, sig, variant):
        if self.conn:
            try:
                self.conn.emit_signal(None, OBJ, BUS, sig, variant)
            except Exception:
                pass

    # ---------- action / tap ----------
    def _activate(self, rec):
        acts = rec.get("actions", [])
        if "default" in acts:
            self._emit("ActionInvoked", GLib.Variant("(us)", (rec["id"], "default")))
        de = rec.get("desktop", "")
        if de:
            try:
                subprocess.Popen(["gtk-launch", de])
            except Exception:
                pass

    # ---------- popups ----------
    def _icon(self, rec, px):
        ic = rec.get("icon", "")
        try:
            if ic.startswith("file://"):
                ic = ic[7:]
            if ic.startswith("/") and os.path.exists(ic):
                return Gtk.Image.new_from_pixbuf(
                    GdkPixbuf.Pixbuf.new_from_file_at_size(ic, px, px))
            if ic:
                th = Gtk.IconTheme.get_default()
                pb = th.load_icon(ic, px, Gtk.IconLookupFlags.FORCE_SIZE)
                return Gtk.Image.new_from_pixbuf(pb)
        except Exception:
            pass
        im = Gtk.Image.new_from_icon_name("dialog-information", Gtk.IconSize.DND)
        im.set_pixel_size(px)
        return im

    def _show_popup(self, rec, timeout):
        win = Gtk.Window(type=Gtk.WindowType.POPUP)
        win.set_type_hint(Gdk.WindowTypeHint.NOTIFICATION)
        win.get_style_context().add_class("npop")
        sc = win.get_screen()
        vis = sc.get_rgba_visual()
        if vis:
            win.set_visual(vis)
        win.set_size_request(360, -1)

        outer = Gtk.EventBox()
        win.add(outer)
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=11)
        box.set_border_width(13)
        outer.add(box)
        box.pack_start(self._icon(rec, 38), False, False, 0)
        txt = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        a = Gtk.Label(label=rec["app"].upper()); a.set_xalign(0)
        a.get_style_context().add_class("app")
        txt.pack_start(a, False, False, 0)
        s = Gtk.Label(label=rec["summary"]); s.set_xalign(0); s.set_line_wrap(True)
        s.get_style_context().add_class("sum")
        txt.pack_start(s, False, False, 0)
        if rec["body"]:
            b = Gtk.Label(label=rec["body"]); b.set_xalign(0); b.set_line_wrap(True)
            b.set_max_width_chars(36); b.get_style_context().add_class("body")
            txt.pack_start(b, False, False, 0)
        box.pack_start(txt, True, True, 0)

        outer.connect("button-press-event",
                      lambda *_: (self._activate(rec), self._close_popup(rec["id"], 2)))

        self.popups.append((rec["id"], win))
        win.show_all()
        self._restack()

        dur = timeout if timeout and timeout > 0 else 5000
        if rec.get("urgency", 1) >= 2:
            dur = 0
        if dur > 0:
            GLib.timeout_add(dur, lambda: (self._close_popup(rec["id"], 1), False)[1])

    def _restack(self):
        sc = Gdk.Screen.get_default()
        sw = sc.get_width() if sc else 1280
        y = BAR_H + 8
        for _id, win in self.popups:
            w, h = win.get_size()
            win.move(sw - 372, y)
            y += h + 8

    def _close_popup(self, nid, reason):
        for i, (pid, win) in enumerate(list(self.popups)):
            if pid == nid:
                try:
                    win.destroy()
                except Exception:
                    pass
                self.popups.pop(i)
                self._emit("NotificationClosed",
                           GLib.Variant("(uu)", (nid, reason)))
                break
        self._restack()
        return False

    # ---------- notification center ----------
    def _toggle_center(self, _data):
        if self.center and self.center.get_visible():
            self.center.hide()
        else:
            if self.center is None:
                self._build_center()
            self._reposition_center()
            self._fill_center()
            self._center_ready = False
            self.center.show_all()
            self.center.present()
            try:
                self.center.get_window().focus(Gdk.CURRENT_TIME)
            except Exception:
                pass
            GLib.timeout_add(450, self._center_ready_cb)
        return True

    def _center_ready_cb(self):
        self._center_ready = True
        return False

    def _center_focus_out(self, *a):
        # ignore the spurious focus-out right after showing; only close once ready
        if getattr(self, "_center_ready", False):
            self.center.hide()
        return True

    def _reposition_center(self):
        # responsive: size/position from the CURRENT screen each time it opens
        sc = self.center.get_screen()
        sh = sc.get_height() if sc else 800
        sw = sc.get_width() if sc else 1280
        W = 380
        self.center.set_size_request(W, sh - BAR_H)
        self.center.resize(W, sh - BAR_H)
        self.center.move(sw - W, BAR_H)

    def _build_center(self):
        w = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        w.set_decorated(False)
        w.set_skip_taskbar_hint(True)
        w.set_skip_pager_hint(True)
        w.set_type_hint(Gdk.WindowTypeHint.UTILITY)
        w.set_keep_above(True)
        w.get_style_context().add_class("ncenter")
        sc = w.get_screen()
        vis = sc.get_rgba_visual()
        if vis:
            w.set_visual(vis)
        w.connect("focus-out-event", self._center_focus_out)
        w.connect("key-press-event", lambda _w, e:
                  w.hide() if e.keyval == Gdk.KEY_Escape else None)

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        w.add(outer)
        t = Gtk.Label(label="Notifications"); t.set_xalign(0)
        t.get_style_context().add_class("title")
        outer.pack_start(t, False, False, 0)
        sc2 = Gtk.ScrolledWindow()
        sc2.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        outer.pack_start(sc2, True, True, 0)
        self._clist = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        sc2.add(self._clist)
        self.center = w

    def _fill_center(self):
        for c in self._clist.get_children():
            c.destroy()
        if not self.history:
            e = Gtk.Label(label="No notifications")
            e.get_style_context().add_class("empty")
            self._clist.pack_start(e, False, False, 0)
            return
        last_day = None
        for rec in reversed(self.history):
            try:
                dt = datetime.fromisoformat(rec["time"])
            except Exception:
                dt = datetime.now()
            day = dt.date()
            if day != last_day:
                last_day = day
                hdr = Gtk.Label(label=self._daylabel(day)); hdr.set_xalign(0)
                hdr.get_style_context().add_class("datehdr")
                self._clist.pack_start(hdr, False, False, 0)
            self._clist.pack_start(self._card(rec, dt), False, False, 0)
        self._clist.show_all()

    def _daylabel(self, day):
        today = date.today()
        if day == today:
            return "TODAY"
        if (today - day).days == 1:
            return "YESTERDAY"
        return day.strftime("%A, %d %B %Y").upper()

    def _card(self, rec, dt):
        ev = Gtk.EventBox()
        ev.get_style_context().add_class("ncard")
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_border_width(10)
        ev.add(box)
        box.pack_start(self._icon(rec, 30), False, False, 0)
        tx = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        ap = Gtk.Label(label=rec["app"]); ap.set_xalign(0)
        ap.get_style_context().add_class("app")
        top.pack_start(ap, True, True, 0)
        tm = Gtk.Label(label=dt.strftime("%H:%M")); tm.set_xalign(1)
        tm.get_style_context().add_class("time")
        top.pack_start(tm, False, False, 0)
        tx.pack_start(top, False, False, 0)
        s = Gtk.Label(label=rec["summary"]); s.set_xalign(0); s.set_line_wrap(True)
        s.get_style_context().add_class("sum")
        tx.pack_start(s, False, False, 0)
        if rec["body"]:
            b = Gtk.Label(label=rec["body"]); b.set_xalign(0); b.set_line_wrap(True)
            b.set_max_width_chars(38); b.get_style_context().add_class("body")
            tx.pack_start(b, False, False, 0)
        box.pack_start(tx, True, True, 0)
        ev.connect("button-press-event", lambda *_: self._activate(rec))
        return ev


def main():
    p = Gtk.CssProvider()
    p.load_from_data(CSS)
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), p, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    Notifyd()
    Gtk.main()


if __name__ == "__main__":
    main()
