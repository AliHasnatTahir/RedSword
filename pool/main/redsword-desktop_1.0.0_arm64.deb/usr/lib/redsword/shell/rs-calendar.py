#!/usr/bin/env python3
# RedSword calendar popover — opens from the top-bar clock. Smoky-black, rounded,
# top-right; closes on focus-out or Escape. (macOS-style date popover.)
import time
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib  # noqa: E402

CSS = b"""
.calpop { background-color: rgba(20,20,22,0.98); border-radius: 14px; }
.calpop .hdr { color: #e9f2ee; font-weight: 800; font-size: 16px; }
.calpop .sub { color: #93a8a0; font-size: 12px; }
.calpop calendar { background-color: transparent; color: #e9f2ee;
    border: none; padding: 4px; }
.calpop calendar:selected { background-color: #3EB489; color: #04120c; }
.calpop calendar.highlight { color: #57D6A6; }
.calpop calendar:indeterminate { color: #63756e; }
.calpop button { background: transparent; border: none; color: #e9f2ee;
    border-radius: 8px; }
.calpop button:hover { background-color: rgba(255,255,255,0.10); }
"""


class CalPop(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_type_hint(Gdk.WindowTypeHint.UTILITY)
        self.set_resizable(False)
        self.get_style_context().add_class("calpop")
        sc = self.get_screen()
        vis = sc.get_rgba_visual()
        if vis:
            self.set_visual(vis)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_border_width(14)
        self.add(box)

        hdr = Gtk.Label(label=time.strftime("%A"))
        hdr.get_style_context().add_class("hdr")
        hdr.set_xalign(0)
        sub = Gtk.Label(label=time.strftime("%d %B %Y   %H:%M"))
        sub.get_style_context().add_class("sub")
        sub.set_xalign(0)
        box.pack_start(hdr, False, False, 0)
        box.pack_start(sub, False, False, 0)

        cal = Gtk.Calendar()
        cal.set_display_options(
            Gtk.CalendarDisplayOptions.SHOW_HEADING
            | Gtk.CalendarDisplayOptions.SHOW_DAY_NAMES)
        box.pack_start(cal, False, False, 4)

        openbtn = Gtk.Button(label="Open Calendar")
        openbtn.connect("clicked", self._open_app)
        box.pack_start(openbtn, False, False, 0)

        self.set_size_request(290, -1)
        self.connect("realize", self._place)
        self.connect("focus-out-event", lambda *a: self.close())
        self.connect("key-press-event", self._key)

    def _place(self, *_):
        sc = self.get_screen()
        w = self.get_size()[0] or 290
        self.move((sc.get_width() or 1280) - w - 8, 34)

    def _open_app(self, *_):
        import subprocess
        for c in ("gnome-calendar", "orage", "xfcalendar"):
            try:
                subprocess.Popen([c]); break
            except Exception:
                continue
        self.close()

    def _key(self, _w, e):
        if e.keyval == Gdk.KEY_Escape:
            self.close()


def main():
    p = Gtk.CssProvider()
    p.load_from_data(CSS)
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), p, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    w = CalPop()
    w.connect("destroy", Gtk.main_quit)
    w.show_all()
    w.present()
    Gtk.main()


if __name__ == "__main__":
    main()
