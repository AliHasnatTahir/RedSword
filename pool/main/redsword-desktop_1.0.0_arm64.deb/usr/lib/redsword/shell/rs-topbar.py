#!/usr/bin/env python3
# RedSword top bar — a docked GTK panel matching the design prototype: RedSword
# logo menu + macOS-style menu bar (Files/File/Edit/View/Go/Help) on the left;
# TOOLS tray + net down/up speed + wifi/bt/battery + clock + control-centre on the
# right. Smoky, ~transparent; mint ONLY on menu selection. Slot icons.
import os
import subprocess
import time
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf  # noqa: E402

BAR_H = 30
LOGO = os.environ.get("REDSWORD_LOGO", "/usr/share/redsword/redsword-logo.png")
AUTOSHOT = os.environ.get("REDSWORD_AUTOSHOT", "")

MENUS = {
    "Files": ["About Files", "-", "Preferences…", "-", "Hide Files", "Quit Files"],
    "File": ["New Window", "New Tab", "New Folder", "-", "Open", "Close Window"],
    "Edit": ["Undo", "Redo", "-", "Cut", "Copy", "Paste", "-", "Select All"],
    "View": ["as Icons", "as List", "-", "Show Hidden Files", "Reload"],
    "Go": ["Home", "Documents", "Downloads", "-", "Computer", "Network"],
    "Help": ["RedSword Help", "Search…"],
}
SYS_MENU = ["About RedSword", "-", "System Settings", "App Center", "-",
            "Lock Screen", "Restart…", "Shut Down…"]

CSS = """
.bar { background-color: rgba(8,8,10,0.34); }
menubar, menubar > menuitem { background: transparent; color: #e9f2ee; font-size: 12px;
    padding: 2px 6px; }
menubar > menuitem:hover, menubar > menuitem:selected { background-color: rgba(255,255,255,0.12);
    border-radius: 6px; }
menu { background-color: rgba(20,20,22,0.98); color: #e9f2ee; border: none; border-radius: 9px; padding: 4px; }
menu menuitem { padding: 6px 10px; border-radius: 6px; font-size: 12px; }
menu menuitem:hover, menu menuitem:selected { background-color: #3EB489; color: #04120c; }
.appname { font-weight: 800; }
.chip { background: transparent; border: none; padding: 2px 6px; border-radius: 6px; color: #e9f2ee; }
.chip:hover { background-color: rgba(255,255,255,0.10); }
.tlbl { font-size: 8px; font-weight: 700; color: #63756e; letter-spacing: 2px; }
.net { font-family: monospace; font-size: 9px; color: #93a8a0; }
.clock { font-family: monospace; font-size: 11px; color: #e9f2ee; }
.tsep { background-color: rgba(255,255,255,0.09); }
"""


def sh(*a):
    try:
        return subprocess.run(a, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                              text=True, timeout=3).stdout.strip()
    except Exception:
        return ""


class TopBar(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.get_style_context().add_class("bar")
        self._prev = (0, 0, time.time())
        try:
            s = Gtk.Settings.get_default()
            s.set_property("gtk-application-prefer-dark-theme", True)
            if os.path.isdir("/usr/share/icons/Slot"):
                s.set_property("gtk-icon-theme-name", "Slot")
        except Exception:
            pass
        # RGBA visual for transparency
        sc = self.get_screen()
        vis = sc.get_rgba_visual()
        if vis:
            self.set_visual(vis)

        root = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(root)
        root.pack_start(self._left(), False, False, 0)
        root.pack_start(Gtk.Box(), True, True, 0)     # spacer
        root.pack_end(self._right(), False, False, 6)

        self.screen_w = sc.get_width() or 1280
        self.set_default_size(self.screen_w, BAR_H)
        self.move(0, 0)
        self.connect("realize", self._on_realize)
        # responsive: re-span + re-reserve when the screen/resolution changes
        sc.connect("size-changed", self._on_screen_resize)
        sc.connect("monitors-changed", self._on_screen_resize)
        GLib.timeout_add_seconds(2, self._tick_net)
        GLib.timeout_add_seconds(10, self._tick_clock)
        # xfdesktop usually lays icons out before our strut reserves the top; nudge
        # it once so desktop icons don't sit under the top/bottom bars.
        GLib.timeout_add(2000, self._nudge_desktop)
        if AUTOSHOT:
            GLib.timeout_add(700, self._shot)

    # ---- left: logo menu + macOS menu bar ------------------------------
    def _left(self):
        mb = Gtk.MenuBar()
        mb.set_valign(Gtk.Align.CENTER)
        # logo item
        logo_item = Gtk.MenuItem()
        img = self._icon_file(LOGO, 17)
        logo_item.add(img)
        logo_item.set_submenu(self._menu(SYS_MENU))
        mb.append(logo_item)
        # app name (bold) + menus
        for i, name in enumerate(("Files", "File", "Edit", "View", "Go", "Help")):
            it = Gtk.MenuItem(label=name)
            if i == 0:
                it.get_child().get_style_context().add_class("appname")
            it.set_submenu(self._menu(MENUS[name]))
            mb.append(it)
        return mb

    def _menu(self, items):
        m = Gtk.Menu()
        for it in items:
            if it == "-":
                m.append(Gtk.SeparatorMenuItem())
            else:
                mi = Gtk.MenuItem(label=it)
                mi.connect("activate", self._menu_action, it)
                m.append(mi)
        m.show_all()
        return m

    def _menu_action(self, _w, label):
        m = {"System Settings": "redsword-settings", "App Center": "redsword-software",
             "Lock Screen": "xflock4", "Shut Down…": "xfce4-session-logout",
             "Restart…": "xfce4-session-logout", "Home": "thunar",
             "Documents": "thunar Documents", "Downloads": "thunar Downloads",
             "New Window": "thunar", "Computer": "thunar computer:///"}
        if label in m:
            self._launch(m[label])

    # ---- right: tools + status -----------------------------------------
    def _right(self):
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        box.set_valign(Gtk.Align.CENTER)
        # TOOLS
        tl = Gtk.Label(label="TOOLS")
        tl.get_style_context().add_class("tlbl")
        box.pack_start(tl, False, False, 4)
        for icon, cmd, tip in (("utilities-terminal", "xfce4-terminal", "Terminal"),
                               ("nmap", "rs-tool-nmap", "Nmap"),
                               ("wireshark", "rs-tool-wireshark", "Wireshark")):
            box.pack_start(self._chip(self._icon(icon, 16), cmd, tip), False, False, 0)
        box.pack_start(self._sep(), False, False, 5)
        # net speed
        self.net = Gtk.Label(label="▼ 0B\n▲ 0B")
        self.net.get_style_context().add_class("net")
        self.net.set_justify(Gtk.Justification.RIGHT)
        box.pack_start(self.net, False, False, 4)
        # wifi / bt / battery — clickable, open real settings tools (with fallbacks)
        for icon, tip, cmd in (
                ("network-wireless", "Wi-Fi — network settings",
                 "nm-connection-editor 2>/dev/null || redsword-control-center"),
                ("bluetooth", "Bluetooth",
                 "blueman-manager 2>/dev/null || redsword-control-center"),
                ("battery", "Battery / Power",
                 "xfce4-power-manager-settings 2>/dev/null || redsword-control-center")):
            box.pack_start(self._chip(self._icon(icon, 15), cmd, tip), False, False, 0)
        # clock (click -> calendar popover)
        self.clock = Gtk.Label()
        self.clock.get_style_context().add_class("clock")
        self._set_clock()
        clock_btn = Gtk.Button()
        clock_btn.get_style_context().add_class("chip")
        clock_btn.set_tooltip_text("Calendar")
        clock_btn.add(self.clock)
        clock_btn.connect("clicked", lambda *_: self._launch("redsword-calendar"))
        box.pack_start(clock_btn, False, False, 6)
        # notifications (bell) -> toggles the Notification Center
        box.pack_start(self._chip(self._icon("notification", 15),
                                  "redsword-notifications", "Notifications"),
                       False, False, 0)
        # control centre
        box.pack_start(self._chip(self._icon("preferences-system", 16),
                                  "redsword-control-center", "Control centre"),
                       False, False, 0)
        return box

    def _chip(self, child, cmd, tip):
        b = Gtk.Button()
        b.get_style_context().add_class("chip")
        b.set_tooltip_text(tip)
        b.add(child)
        if cmd:
            b.connect("clicked", lambda *_: self._launch(cmd))
        return b

    def _sep(self):
        s = Gtk.Box()
        s.get_style_context().add_class("tsep")
        s.set_size_request(1, 16)
        s.set_valign(Gtk.Align.CENTER)
        return s

    # ---- ticks ----------------------------------------------------------
    def _tick_clock(self):
        self._set_clock()
        return True

    def _set_clock(self):
        self.clock.set_text(time.strftime("%a %d %b  %H:%M"))

    def _tick_net(self):
        # Sum every real (non-loopback, non-virtual) interface so the speed shows
        # regardless of which iface holds the default route.
        import glob
        rx = tx = 0
        for rp in glob.glob("/sys/class/net/*/statistics/rx_bytes"):
            iface = rp.split("/")[4]
            if iface == "lo" or iface.startswith(("veth", "docker", "br-", "virbr")):
                continue
            try:
                rx += int(open(rp).read())
                tx += int(open(rp.replace("rx_bytes", "tx_bytes")).read())
            except Exception:
                pass
        now = time.time()
        prx, ptx, pnow = self._prev
        self._prev = (rx, tx, now)
        if prx == 0 and ptx == 0:   # first reading: prime, don't show a spike
            self.net.set_text("▼ 0B\n▲ 0B")
            return True
        dt = max(1, now - pnow)
        drx = max(0, int((rx - prx) / dt)); dtx = max(0, int((tx - ptx) / dt))

        def h(b):
            if b >= 1048576:
                return f"{b/1048576:.1f}M"
            if b >= 1024:
                return f"{b//1024}K"
            return f"{b}B"
        self.net.set_text(f"▼ {h(drx)}\n▲ {h(dtx)}")
        return True

    # ---- helpers --------------------------------------------------------
    def _icon(self, name, px):
        theme = Gtk.IconTheme.get_default()
        for n in (name, name + "-symbolic"):
            try:
                pb = theme.load_icon(n, px, Gtk.IconLookupFlags.FORCE_SIZE)
                if pb:
                    im = Gtk.Image.new_from_pixbuf(pb); im.set_size_request(px, px)
                    return im
            except Exception:
                continue
        im = Gtk.Image.new_from_icon_name(name, Gtk.IconSize.MENU)
        im.set_pixel_size(px)
        return im

    def _icon_file(self, path, px):
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, px, px, True)
            return Gtk.Image.new_from_pixbuf(pb)
        except Exception:
            return Gtk.Image.new_from_icon_name("start-here", Gtk.IconSize.MENU)

    def _launch(self, cmd):
        try:
            subprocess.Popen(["sh", "-c", cmd])
        except Exception:
            pass

    def _nudge_desktop(self):
        # recompute the desktop workarea now that our top strut is in place
        self._launch("xfdesktop --reload")
        return False  # one-shot

    def _on_realize(self, *_):
        self._apply_geometry()

    def _on_screen_resize(self, screen, *_):
        # resolution/monitor changed -> re-span the bar + re-reserve + re-layout icons
        self.screen_w = screen.get_width() or self.screen_w
        self._apply_geometry()
        GLib.timeout_add(500, self._nudge_desktop)

    def _apply_geometry(self):
        w = self.get_window()
        if w is None:
            return
        try:
            self.resize(self.screen_w, BAR_H)
            self.move(0, 0)
            w.resize(self.screen_w, BAR_H)
            # reserve space at the top (strut) so windows don't cover the bar
            data = [0, 0, BAR_H, 0]
            partial = [0, 0, BAR_H, 0, 0, 0, 0, 0, 0, self.screen_w - 1, 0, 0]
            self._strut("_NET_WM_STRUT", data)
            self._strut("_NET_WM_STRUT_PARTIAL", partial)
        except Exception:
            pass
        # Reliable fallback: GDK property_change for CARDINAL arrays doesn't always
        # register with the WM, so set the struts with xprop too.
        try:
            xid = w.get_xid()
            W = self.screen_w
            subprocess.Popen([
                "sh", "-c",
                f'xprop -id {xid} -f _NET_WM_STRUT 32c '
                f'-set _NET_WM_STRUT "0,0,{BAR_H},0"; '
                f'xprop -id {xid} -f _NET_WM_STRUT_PARTIAL 32c '
                f'-set _NET_WM_STRUT_PARTIAL "0,0,{BAR_H},0,0,0,0,0,0,{W-1},0,0"'])
        except Exception:
            pass

    def _strut(self, name, values):
        w = self.get_window()
        atom = Gdk.Atom.intern(name, False)
        card = Gdk.Atom.intern("CARDINAL", False)
        w.property_change(atom, card, 32, Gdk.PropMode.REPLACE, values)

    def _shot(self):
        win = self.get_window()
        if win is None:
            return
        wd, ht = self.get_size()
        pb = Gdk.pixbuf_get_from_window(win, 0, 0, wd, ht)
        if pb:
            pb.savev(f"{AUTOSHOT}/topbar.png", "png", [], [])
            print("shot", flush=True)
        GLib.timeout_add(300, Gtk.main_quit)


def main():
    provider = Gtk.CssProvider()
    provider.load_from_data(CSS.encode())
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    win = TopBar()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
