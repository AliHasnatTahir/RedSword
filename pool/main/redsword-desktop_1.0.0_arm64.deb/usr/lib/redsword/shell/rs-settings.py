#!/usr/bin/env python3
# RedSword System Settings — a macOS-style settings app: a left sidebar of categories,
# the real setting embedded inline on the right (XFCE dialogs via XEmbed --socket-id).
# Dark/onyx + mint, rounded, Manrope. Window buttons come from the WM (traffic lights).
import os
import subprocess
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf  # noqa: E402

LOGO = os.environ.get("REDSWORD_LOGO", "/usr/share/redsword/redsword-logo.png")

# (label, icon-name, command, embeds?)   command=None -> custom About pane
GROUPS = [
    ("General", [
        ("Appearance", "preferences-desktop-theme", "xfce4-appearance-settings", True),
        ("Desktop & Wallpaper", "preferences-desktop-wallpaper", "xfdesktop-settings", True),
        ("Notifications", "preferences-desktop-notification", "redsword-notifications", False),
        ("Panel", "preferences-desktop", "xfce4-panel --preferences", False),
    ]),
    ("Hardware", [
        ("Displays", "preferences-desktop-display", "xfce4-display-settings", True),
        ("Keyboard", "preferences-desktop-keyboard", "xfce4-keyboard-settings", True),
        ("Mouse & Touchpad", "preferences-desktop-peripherals", "xfce4-mouse-settings", True),
        ("Battery & Power", "preferences-system-power", "xfce4-power-manager-settings", True),
        ("Color", "preferences-color", "xfce4-color-settings", True),
    ]),
    ("Network", [
        ("Wi-Fi & Network", "preferences-system-network", "nm-connection-editor", False),
    ]),
    ("System", [
        ("Software Update", "system-software-update", "redsword-update", False),
        ("Window Manager", "preferences-system-windows", "xfwm4-settings", True),
        ("Window Tweaks", "preferences-system-windows", "xfwm4-tweaks-settings", True),
        ("Workspaces", "preferences-desktop-display", "xfwm4-workspace-settings", True),
        ("Session & Startup", "preferences-system-session", "xfce4-session-settings", True),
        ("Accessibility", "preferences-desktop-accessibility", "xfce4-accessibility-settings", True),
        ("About", "help-about", None, None),
    ]),
]

CSS = b"""
.rs-settings { background-color: #0f1513; }
.sidebar { background-color: rgba(255,255,255,0.03); }
.sidebar list, .sidebar { background-color: transparent; }
.grp { color: #63756e; font-size: 10px; font-weight: 800; letter-spacing: 1.5px;
       margin: 14px 14px 4px 16px; }
row.srow { padding: 0; }
.item { padding: 7px 12px; border-radius: 8px; margin: 1px 8px; color: #e9f2ee; }
.item:hover { background-color: rgba(255,255,255,0.07); }
row:selected .item, row.srow:selected { background-color: #3EB489; }
row:selected .item label { color: #04120c; }
.item label { color: #e9f2ee; font-size: 13px; }
.search { margin: 12px 10px 6px 10px; }
.content { background-color: #0f1513; }
.phead { color: #e9f2ee; font-size: 20px; font-weight: 800; margin: 18px 22px 2px; }
.psub  { color: #93a8a0; font-size: 12px; margin: 0 22px 10px; }
.openbtn { background-color: #3EB489; color: #04120c; border-radius: 9px;
           padding: 9px 18px; font-weight: 700; }
.abouttitle { color: #e9f2ee; font-size: 22px; font-weight: 800; }
.aboutsub { color: #93a8a0; font-size: 12px; }
"""


class Settings(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.set_title("System Settings")
        self.set_wmclass("redsword-settings", "RedSword Settings")
        self.set_default_size(880, 580)
        self.get_style_context().add_class("rs-settings")
        self._child = None
        try:
            s = Gtk.Settings.get_default()
            if os.path.isdir("/usr/share/icons/Slot"):
                s.set_property("gtk-icon-theme-name", "Slot")
        except Exception:
            pass

        root = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(root)

        # ---------- sidebar ----------
        side = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        side.get_style_context().add_class("sidebar")
        side.set_size_request(240, -1)
        root.pack_start(side, False, False, 0)

        search = Gtk.SearchEntry()
        search.get_style_context().add_class("search")
        search.set_placeholder_text("Search")
        search.connect("search-changed", self._on_search)
        side.pack_start(search, False, False, 0)

        sc = Gtk.ScrolledWindow()
        sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        side.pack_start(sc, True, True, 0)
        self.listbox = Gtk.ListBox()
        self.listbox.get_style_context().add_class("sidebar")
        self.listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.listbox.set_header_func(self._hdr, None)
        self.listbox.connect("row-selected", self._on_row)
        sc.add(self.listbox)

        self._rows = []
        first = None
        for gi_, (group, items) in enumerate(GROUPS):
            for it in items:
                row = Gtk.ListBoxRow()
                row.get_style_context().add_class("srow")
                row.group = group
                row.item = it
                box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
                box.get_style_context().add_class("item")
                box.pack_start(self._icon(it[1], 20), False, False, 0)
                lbl = Gtk.Label(label=it[0]); lbl.set_xalign(0)
                box.pack_start(lbl, True, True, 0)
                row.add(box)
                self.listbox.add(row)
                self._rows.append(row)
                if first is None:
                    first = row

        # ---------- content ----------
        self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.content.get_style_context().add_class("content")
        root.pack_start(self.content, True, True, 0)

        self.show_all()
        if first:
            self.listbox.select_row(first)

    # ---- sidebar helpers ----
    def _hdr(self, row, before, _d):
        if before is None or before.group != row.group:
            lbl = Gtk.Label(label=row.group.upper())
            lbl.get_style_context().add_class("grp")
            lbl.set_xalign(0)
            lbl.show()
            row.set_header(lbl)
        else:
            row.set_header(None)

    def _on_search(self, entry):
        q = entry.get_text().lower().strip()
        for row in self._rows:
            row.set_visible(not q or q in row.item[0].lower())

    def _on_row(self, _lb, row):
        if row is None:
            return
        self._open(row.item)

    # ---- content ----
    def _clear(self):
        if self._child is not None:
            try:
                self._child.terminate()
            except Exception:
                pass
            self._child = None
        for c in self.content.get_children():
            c.destroy()

    def _open(self, item):
        label, icon, cmd, embeds = item
        self._clear()
        if cmd is None:
            self.content.add(self._about())
            self.content.show_all()
            return
        if embeds:
            sock = Gtk.Socket()
            self.content.pack_start(sock, True, True, 0)
            self.content.show_all()
            while Gtk.events_pending():
                Gtk.main_iteration()
            xid = sock.get_id()
            try:
                self._child = subprocess.Popen(
                    cmd.split() + ["--socket-id=%d" % xid])
                return
            except Exception:
                self._clear()
        # fallback: external launch pane
        self.content.add(self._launch_pane(label, icon, cmd))
        self.content.show_all()

    def _launch_pane(self, label, icon, cmd):
        b = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        b.set_valign(Gtk.Align.CENTER); b.set_halign(Gtk.Align.CENTER)
        b.pack_start(self._icon(icon, 56), False, False, 0)
        h = Gtk.Label(label=label); h.get_style_context().add_class("abouttitle")
        b.pack_start(h, False, False, 0)
        btn = Gtk.Button(label="Open " + label)
        btn.get_style_context().add_class("openbtn")
        btn.connect("clicked", lambda *_: subprocess.Popen(cmd.split()))
        b.pack_start(btn, False, False, 0)
        return b

    def _about(self):
        b = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        b.set_valign(Gtk.Align.CENTER); b.set_halign(Gtk.Align.CENTER)
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(LOGO, 96, 96, True)
            b.pack_start(Gtk.Image.new_from_pixbuf(pb), False, False, 0)
        except Exception:
            pass
        t = Gtk.Label(label="RedSword"); t.get_style_context().add_class("abouttitle")
        b.pack_start(t, False, False, 0)

        def info(cmd):
            try:
                return subprocess.run(cmd, shell=True, capture_output=True,
                                      text=True, timeout=3).stdout.strip()
            except Exception:
                return ""
        lines = [
            "RedSword 0.1  ·  arm64",
            "Kernel  " + info("uname -r"),
            "CPU  " + (info("nproc") + " cores"),
            "Memory  " + info("free -h 2>/dev/null | awk '/Mem:/{print $2}'"),
        ]
        for ln in lines:
            lab = Gtk.Label(label=ln); lab.get_style_context().add_class("aboutsub")
            b.pack_start(lab, False, False, 0)
        return b

    # ---- icons ----
    def _icon(self, name, px):
        theme = Gtk.IconTheme.get_default()
        for n in (name, name + "-symbolic", "preferences-system"):
            try:
                pb = theme.load_icon(n, px, Gtk.IconLookupFlags.FORCE_SIZE)
                if pb:
                    return Gtk.Image.new_from_pixbuf(pb)
            except Exception:
                continue
        return Gtk.Image.new_from_icon_name("preferences-system", Gtk.IconSize.DND)


def main():
    p = Gtk.CssProvider()
    p.load_from_data(CSS)
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), p, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    w = Settings()
    w.connect("destroy", Gtk.main_quit)
    w.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
