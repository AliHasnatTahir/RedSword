#!/usr/bin/env python3
# RedSword Mint menu — the bottom-left application menu, built to match the design
# prototype exactly: 3 columns (quick-launch strip · categories · apps+search),
# smoky-black, mint ONLY on the selected category / hovered app. Slot icons.
import os
import subprocess
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf  # noqa: E402

MINT = "#3EB489"
LOGO = os.environ.get("REDSWORD_LOGO", "/usr/share/redsword/redsword-logo.png")
AUTOSHOT = os.environ.get("REDSWORD_AUTOSHOT", "")

# (label, slot-icon, command) — commands are best-effort; missing apps fail quietly.
CATS = [
    ("All Applications", "applications-all", [
        ("Firefox", "firefox", "web browser", "firefox-esr"),
        ("Files", "system-file-manager", "file manager", "thunar"),
        ("Terminal", "utilities-terminal", "shell", "xfce4-terminal"),
        ("Nmap", "nmap", "network scan · kali", "rs-tool-nmap"),
        ("RedSword Software", "gnome-software", "app center", "redsword-software"),
        ("GIMP", "gimp", "image editor", "gimp"),
        ("VLC", "vlc", "media player", "vlc"),
        ("Wireshark", "wireshark", "packet capture · kali", "rs-tool-wireshark")]),
    ("Accessories", "applications-accessories", [
        ("Terminal", "utilities-terminal", "shell", "xfce4-terminal"),
        ("Text Editor", "accessories-text-editor", "notes", "mousepad"),
        ("Calculator", "accessories-calculator", "", "galculator")]),
    ("Graphics", "applications-graphics", [
        ("GIMP", "gimp", "image editor", "gimp"),
        ("Inkscape", "inkscape", "vector", "inkscape"),
        ("Image Viewer", "image-x-generic", "", "ristretto")]),
    ("Internet", "applications-internet", [
        ("Firefox", "firefox", "web browser", "firefox-esr"),
        ("Thunderbird", "thunderbird", "mail", "thunderbird"),
        ("Transmission", "transmission", "torrent", "transmission-gtk")]),
    ("Office", "applications-office", [
        ("LibreOffice Writer", "libreoffice-writer", "", "libreoffice --writer"),
        ("LibreOffice Calc", "libreoffice-calc", "", "libreoffice --calc"),
        ("LibreOffice Impress", "libreoffice-impress", "", "libreoffice --impress")]),
    ("Sound & Video", "applications-multimedia", [
        ("VLC", "vlc", "media player", "vlc"),
        ("Audacity", "audacity", "audio", "audacity"),
        ("OBS Studio", "obs", "recording", "obs")]),
    ("Security Toolkit", "distributor-logo-kali-linux", [
        ("Nmap", "nmap", "network scan", "rs-tool-nmap"),
        ("Wireshark", "wireshark", "packet capture", "rs-tool-wireshark"),
        ("John the Ripper", "dialog-password", "password audit", "john"),
        ("Aircrack-ng", "aircrack-ng", "wi-fi audit", "aircrack-ng"),
        ("sqlmap", "utilities-terminal", "web audit", "sqlmap"),
        ("Metasploit", "security-high", "framework", "msfconsole")]),
    ("Administration", "applications-system", [
        ("Disks", "drive-harddisk", "", "gnome-disks"),
        ("System Monitor", "utilities-system-monitor", "", "xfce4-taskmanager"),
        ("RedSword Boxes", "distributor-logo-kali-linux", "Debian/Ubuntu/Kali", "xfce4-terminal -e redsword")]),
    ("Preferences", "preferences-desktop", [
        ("Appearance", "preferences-desktop-theme", "theme", "xfce4-appearance-settings"),
        ("Network", "network-wireless", "", "nm-connection-editor"),
        ("Software Update", "system-software-update", "update upgrade", "redsword-update"),
        ("Settings", "preferences-system", "", "xfce4-settings-manager")]),
    ("Places", "folder-home", [
        ("Home", "folder-home", "", "thunar"),
        ("Documents", "folder-documents", "", "thunar Documents"),
        ("Downloads", "folder-download", "", "thunar Downloads")]),
]

CSS = f"""
window, .menu {{ background-color: #141416; color: #e9f2ee; }}
.menu {{ border-radius: 12px; }}
.quick {{ background-color: rgba(0,0,0,0.28); }}
.q {{ background: transparent; border: none; padding: 6px; border-radius: 9px; }}
.q:hover {{ background-color: rgba(255,255,255,0.08); }}
.cats {{ background-color: transparent; }}
.cat {{ padding: 0; }}
.cat-lbl {{ font-size: 12px; color: #e9f2ee; }}
.cats row:selected {{ background-color: {MINT}; border-radius: 7px; }}
.cats row:selected .cat-lbl {{ color: #04120c; font-weight: 700; }}
.search {{ background-color: rgba(255,255,255,0.04); border-bottom: 1px solid rgba(255,255,255,0.08); }}
entry {{ background: transparent; border: none; color: #e9f2ee; }}
.appname {{ font-size: 12px; color: #e9f2ee; }}
.appdesc {{ font-size: 10px; color: #63756e; }}
.applist row {{ padding: 0; }}
.applist row:selected, .applist row:hover {{ background-color: rgba(255,255,255,0.07); border-radius: 7px; }}
.user {{ font-size: 11px; color: #93a8a0; }}
"""


def sh_ok(*a):
    try:
        return subprocess.call(["which", a[0]], stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL) == 0
    except Exception:
        return False


class Menu(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_size_request(524, 404)
        self.set_skip_taskbar_hint(True)
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.get_style_context().add_class("menu")
        try:
            Gtk.Settings.get_default().set_property(
                "gtk-application-prefer-dark-theme", True)
            if os.path.isdir("/usr/share/icons/Slot"):
                Gtk.Settings.get_default().set_property("gtk-icon-theme-name", "Slot")
        except Exception:
            pass
        self._armed = False
        if not AUTOSHOT:
            self.connect("focus-out-event", self._focus_out)
            self.connect("key-press-event", self._key)
            GLib.timeout_add(500, self._arm)

        grid = Gtk.Grid()
        self.add(grid)
        grid.attach(self._quick(), 0, 0, 1, 1)
        grid.attach(self._categories(), 1, 0, 1, 1)
        grid.attach(self._right(), 2, 0, 1, 1)

        self._select_cat(0)
        if AUTOSHOT:
            GLib.timeout_add(650, self._shot)

    # ---- columns --------------------------------------------------------
    def _quick(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.get_style_context().add_class("quick")
        box.set_size_request(52, -1)
        box.set_border_width(9)
        for name, cmd in (("firefox", "firefox-esr"),
                          ("system-file-manager", "thunar"),
                          ("utilities-terminal", "xfce4-terminal")):
            box.pack_start(self._qbtn(name, cmd, 22), False, False, 0)
        box.pack_start(Gtk.Box(), True, True, 0)   # grow
        for name, cmd, col in (("system-lock-screen", "xflock4", "#93a8a0"),
                               ("avatar-default", None, "#93a8a0"),
                               ("system-shutdown", "xfce4-session-logout", "#e2574a")):
            box.pack_start(self._qbtn(name, cmd, 19), False, False, 0)
        return box

    def _qbtn(self, icon, cmd, px):
        b = Gtk.Button()
        b.get_style_context().add_class("q")
        b.add(self._icon(icon, px))
        if cmd:
            b.connect("clicked", lambda *_: self._launch(cmd))
        return b

    def _categories(self):
        self.catlist = Gtk.ListBox()
        self.catlist.get_style_context().add_class("cats")
        self.catlist.set_size_request(152, -1)
        self.catlist.set_selection_mode(Gtk.SelectionMode.SINGLE)
        for i, (label, icon, _apps) in enumerate(CATS):
            row = Gtk.ListBoxRow()
            row.idx = i
            hb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=9)
            hb.set_border_width(7)
            hb.pack_start(self._icon(icon, 18), False, False, 0)
            lb = Gtk.Label(label=label, xalign=0)
            lb.get_style_context().add_class("cat-lbl")
            hb.pack_start(lb, True, True, 0)
            row.add(hb)
            self.catlist.add(row)
        self.catlist.connect("row-selected", self._on_cat)
        wrap = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        wrap.set_border_width(6)
        wrap.pack_start(self.catlist, True, True, 0)
        return wrap

    def _right(self):
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        col.set_hexpand(True)
        # search at top
        sb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        sb.get_style_context().add_class("search")
        sb.set_border_width(9)
        sb.pack_start(self._icon("system-search", 15), False, False, 0)
        self.search = Gtk.Entry()
        self.search.set_has_frame(False)
        self.search.set_placeholder_text("Search applications…")
        self.search.connect("changed", self._on_search)
        sb.pack_start(self.search, True, True, 0)
        col.pack_start(sb, False, False, 0)
        # app list
        self.applist = Gtk.ListBox()
        self.applist.get_style_context().add_class("applist")
        self.applist.set_selection_mode(Gtk.SelectionMode.NONE)
        self.applist.connect("row-activated", self._on_app)
        sc = Gtk.ScrolledWindow()
        sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sc.set_vexpand(True)
        sc.add(self.applist)
        sc.set_border_width(6)
        col.pack_start(sc, True, True, 0)
        return col

    # ---- app rendering --------------------------------------------------
    def _cmd_ok(self, cmd):
        import shutil
        try:
            return shutil.which(cmd.split()[0]) is not None
        except Exception:
            return False

    def _fill_apps(self, apps):
        for c in self.applist.get_children():
            self.applist.remove(c)
        for (name, icon, desc, cmd) in apps:
            if not self._cmd_ok(cmd):     # hide apps that aren't installed
                continue
            row = Gtk.ListBoxRow()
            row.cmd = cmd
            hb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            hb.set_border_width(7)
            hb.pack_start(self._icon(icon, 22), False, False, 0)
            t = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            t.set_valign(Gtk.Align.CENTER)
            nl = Gtk.Label(label=name, xalign=0)
            nl.get_style_context().add_class("appname")
            t.pack_start(nl, False, False, 0)
            if desc:
                dl = Gtk.Label(label=desc, xalign=0)
                dl.get_style_context().add_class("appdesc")
                t.pack_start(dl, False, False, 0)
            hb.pack_start(t, True, True, 0)
            row.add(hb)
            self.applist.add(row)
        self.applist.show_all()

    def _select_cat(self, i):
        self.catlist.select_row(self.catlist.get_row_at_index(i))

    def _on_cat(self, _lb, row):
        if row is not None:
            self._fill_apps(CATS[row.idx][2])

    def _on_search(self, entry):
        q = entry.get_text().lower().strip()
        if not q:
            r = self.catlist.get_selected_row()
            self._fill_apps(CATS[r.idx if r else 0][2])
            return
        seen, out = set(), []
        for _l, _i, apps in CATS:
            for a in apps:
                if a[0] not in seen and (q in a[0].lower() or q in a[2].lower()):
                    seen.add(a[0]); out.append(a)
        self._fill_apps(out)

    def _on_app(self, _lb, row):
        self._launch(row.cmd)

    # ---- helpers --------------------------------------------------------
    def _icon(self, name, px):
        theme = Gtk.IconTheme.get_default()
        for n in (name, name + "-symbolic", "application-x-executable"):
            try:
                pb = theme.load_icon(n, px, Gtk.IconLookupFlags.FORCE_SIZE)
                if pb is not None:
                    img = Gtk.Image.new_from_pixbuf(pb)
                    img.set_size_request(px, px)
                    return img
            except Exception:
                continue
        return Gtk.Image()

    def _launch(self, cmd):
        try:
            subprocess.Popen(["sh", "-c", cmd])
        except Exception:
            pass
        if not AUTOSHOT:
            self.close()

    def _arm(self):
        self._armed = True
        return False

    def _focus_out(self, *_):
        if self._armed:
            self.close()
        return False

    def _key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self.close()

    def _shot(self):
        win = self.get_window()
        if win is None:
            return
        w, h = self.get_size()
        pb = Gdk.pixbuf_get_from_window(win, 0, 0, w, h)
        if pb:
            pb.savev(f"{AUTOSHOT}/menu.png", "png", [], [])
            print("shot", flush=True)
        GLib.timeout_add(300, Gtk.main_quit)


def main():
    provider = Gtk.CssProvider()
    provider.load_from_data(CSS.encode())
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    win = Menu()
    win.connect("destroy", Gtk.main_quit)
    if AUTOSHOT:
        win.set_position(Gtk.WindowPosition.CENTER)
        win.show_all()
    else:
        win.show_all()
        try:
            sc = Gdk.Screen.get_default()
            win.move(8, sc.get_height() - 404 - 52)   # bottom-left, above the dock
        except Exception:
            win.set_position(Gtk.WindowPosition.MOUSE)
    Gtk.main()


if __name__ == "__main__":
    main()
