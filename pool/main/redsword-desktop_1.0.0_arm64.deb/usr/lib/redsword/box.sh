# shellcheck shell=bash
# RedSword box lifecycle: create / update / enter / exec a single-ecosystem container.
# Sourced by the `redsword` CLI; assumes root.

RS_ROOT=${RS_ROOT:-/var/lib/redsword}
RS_BOXES=$RS_ROOT/boxes
RS_CONF=${RS_CONF:-/etc/redsword/boxes.conf}
RS_SHARE=${RS_SHARE:-/usr/share/redsword}
RS_BASES=$RS_SHARE/bases      # bundled base images: <box>.tar.zst
RS_KEYS=$RS_SHARE/keys        # bundled signing keys: <box>.gpg
RS_ARCH=${RS_ARCH:-$( (command -v dpkg >/dev/null && dpkg --print-architecture) 2>/dev/null || \
    case "$(uname -m)" in aarch64) echo arm64;; x86_64) echo amd64;; *) uname -m;; esac )}

rs_die(){ echo "redsword: $*" >&2; exit 1; }
rs_box_dir(){ echo "$RS_BOXES/$1"; }
rs_box_exists(){ [ -e "$(rs_box_dir "$1")/etc/os-release" ]; }

# Read one box's definition line into RS_SUITE / RS_MIRROR / RS_COMPONENTS / RS_KEYURL.
rs_box_def(){
    local name=$1 line
    line=$(grep -E "^${name}[[:space:]]" "$RS_CONF" | head -1) || true
    [ -n "$line" ] || rs_die "unknown box '$name' (not in $RS_CONF)"
    read -r _ RS_SUITE RS_MIRROR RS_COMPONENTS RS_KEYURL <<<"$line"
}

rs_default_box(){ awk '/^default[[:space:]]/{print $2; exit}' "$RS_CONF"; }
rs_all_boxes(){ awk '!/^#/ && !/^default[[:space:]]/ && NF{print $1}' "$RS_CONF"; }

# Resolve this box's signing key: bundled key wins; else fetch (dev hosts with curl+gpg).
rs_box_key(){
    local name=$1
    if [ -f "$RS_KEYS/$name.gpg" ]; then echo "$RS_KEYS/$name.gpg"; return 0; fi
    [ "$RS_KEYURL" != "—" ] && [ -n "$RS_KEYURL" ] || return 1
    command -v curl >/dev/null || return 1
    local keyring=$RS_ROOT/keys/$name.gpg tmp
    mkdir -p "$RS_ROOT/keys"; tmp="$keyring.dl"
    echo ">> fetching $name signing key" >&2
    curl -fsSL "$RS_KEYURL" -o "$tmp" || return 1
    if [ "${RS_KEYURL##*.}" = asc ]; then
        command -v gpg >/dev/null || return 1
        gpg --dearmor < "$tmp" > "$keyring" && rm -f "$tmp"
    else
        mv -f "$tmp" "$keyring"
    fi
    echo "$keyring"
}

# Write a box's apt config so it sees ONLY its own ecosystem.
rs_box_apt_config(){
    local name=$1 dir=$2 keyring=$3 signed=""
    if [ -n "$keyring" ]; then
        install -Dm644 "$keyring" "$dir/usr/share/keyrings/$name.gpg"
        signed="[signed-by=/usr/share/keyrings/$name.gpg] "
    fi
    printf 'deb %s%s %s %s\n' "$signed" "$RS_MIRROR" "$RS_SUITE" "${RS_COMPONENTS//,/ }" \
        > "$dir/etc/apt/sources.list"
    mkdir -p "$dir/etc/apt/sources.list.d" "$dir/etc/apt/apt.conf.d" "$dir/etc/profile.d"
    cat > "$dir/etc/apt/apt.conf.d/90redsword" <<'EOF'
APT::Install-Recommends "false";
APT::Get::Assume-Yes "true";
Acquire::Languages "none";
EOF
    echo 'export DEBIAN_FRONTEND=noninteractive' > "$dir/etc/profile.d/redsword.sh"
    echo "$name" > "$dir/etc/redsword-box"
}

# Create a box for one ecosystem. Prefers a bundled base image (no downloader/gpg needed on
# the host); falls back to debootstrap on dev hosts that have it.
rs_box_create(){
    local name=$1; rs_box_def "$name"
    local dir; dir=$(rs_box_dir "$name")
    rs_box_exists "$name" && { echo "box '$name' already exists"; return 0; }
    mkdir -p "$dir"
    local keyring; keyring=$(rs_box_key "$name" || true)

    if [ -f "$RS_BASES/$name.tar.zst" ]; then
        echo ">> creating '$name' box from bundled base image"
        tar --zstd -xpf "$RS_BASES/$name.tar.zst" -C "$dir" \
            || rs_die "could not unpack bundled base for $name"
        rs_box_apt_config "$name" "$dir" "$keyring"
        # Refresh package lists from the live mirror (box has its own apt + key + network).
        rs_box_run "$name" apt-get update -qq || echo ">> (offline — apt lists will refresh on first install)"
    elif command -v debootstrap >/dev/null; then
        [ -n "$keyring" ] || rs_die "no signing key for $name (bundle one in $RS_KEYS or install curl+gpg)"
        [ -e /usr/share/debootstrap/scripts/"$RS_SUITE" ] || ln -sf sid /usr/share/debootstrap/scripts/"$RS_SUITE"
        echo ">> creating '$name' box via debootstrap ($RS_SUITE, $RS_ARCH) — downloads a base system"
        debootstrap --arch="$RS_ARCH" --variant=minbase --components="$RS_COMPONENTS" \
            --keyring "$keyring" "$RS_SUITE" "$dir" "$RS_MIRROR" || rs_die "debootstrap failed for $name"
        rs_box_apt_config "$name" "$dir" "$keyring"
        rs_box_run "$name" apt-get update -qq || true
    else
        rs_die "cannot create '$name': no bundled base at $RS_BASES/$name.tar.zst and no debootstrap on host"
    fi
    echo ">> box '$name' ready at $dir"
}

# Ensure a box is running as a warm registered machine; echo its leader PID.
rs_box_warm(){
    local name=$1 machine="redsword-$name" leader
    if ! systemctl is-active --quiet "redsword-box@$name"; then
        systemctl start "redsword-box@$name" || return 1
    fi
    for _ in $(seq 1 60); do
        leader=$(machinectl show "$machine" -p Leader --value 2>/dev/null || true)
        [ -n "$leader" ] && { echo "$leader"; return 0; }
        sleep 0.25
    done
    return 1
}

# Run a command inside a box (management: apt, dpkg, queries). Enters the ONE warm box via
# nsenter, so it never conflicts with the box already running for GUI apps.
rs_box_run(){
    local name=$1; shift
    local leader; leader=$(rs_box_warm "$name") || rs_die "box '$name' failed to start"
    nsenter -t "$leader" -m -u -i -n -p -r -w -- \
        env DEBIAN_FRONTEND=noninteractive LC_ALL=C \
        PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games "$@"
}

rs_require_box(){ rs_box_exists "$1" || rs_die "box '$1' does not exist yet — run: redsword box create $1"; }
