#!/usr/bin/env python3
# RedSword Software Update — an iOS-style updater. Reads the last check result for an
# instant view, checks on demand, and installs updates with live progress. All apt
# work is done by redsword-update-root via pkexec (so the user authorizes once).
import gi, json, os, datetime
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib, Gio

ROOT_HELPER = "/usr/lib/redsword/update/redsword-update-root"
STATUS = "/var/lib/redsword/update-status.json"
LOGO = "/usr/share/redsword/redsword-logo.png"
MINT = "#3EB489"

CSS = ("""
window,.rs-root{background-color:#141414;color:#e8e8e8;}
.rs-title{font-size:21px;font-weight:700;}
.rs-sub{color:#a7a7a7;font-size:13px;}
.rs-ver{font-size:15px;font-weight:600;}
.rs-card{background-color:#1c1c1c;border-radius:14px;padding:18px;}
.rs-btn{background-image:none;background-color:#242424;color:#e8e8e8;border:none;border-radius:9px;padding:9px 20px;}
.rs-btn:hover{background-color:#2c2c2c;}
.rs-primary{background-image:none;background-color:%s;color:#08130f;font-weight:700;border:none;border-radius:9px;padding:9px 20px;}
.rs-primary:hover{background-color:#46c79a;}
.rs-primary:disabled{background-color:#23342d;color:#4d6a5e;}
.rs-ok{color:%s;font-weight:700;}
.rs-log{background-color:#0d0d0d;color:#9fdcc4;font-family:monospace;font-size:11px;padding:8px;border-radius:8px;}
progressbar progress{background-color:%s;border-radius:6px;min-height:7px;}
progressbar trough{background-color:#202020;border-radius:6px;min-height:7px;}
""" % (MINT, MINT, MINT))


def read_status():
    try:
        with open(STATUS) as f:
            return json.load(f)
    except Exception:
        return {}


class Updater(Gtk.Window):
    def __init__(self):
        super().__init__(title="Software Update")
        self.set_default_size(540, 440)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.get_style_context().add_class("rs-root")
        try:
            Gtk.Settings.get_default().set_property("gtk-application-prefer-dark-theme", True)
        except Exception:
            pass
        self.proc = None
        self._pulse = None

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        outer.set_border_width(24)
        self.add(outer)

        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        if os.path.exists(LOGO):
            try:
                from gi.repository import GdkPixbuf
                pb = GdkPixbuf.Pixbuf.new_from_file_at_size(LOGO, 56, 56)
                head.pack_start(Gtk.Image.new_from_pixbuf(pb), False, False, 0)
            except Exception:
                pass
        tbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        t = Gtk.Label(label="Software Update", xalign=0); t.get_style_context().add_class("rs-title")
        self.sub = Gtk.Label(label="RedSword", xalign=0); self.sub.get_style_context().add_class("rs-sub")
        tbox.pack_start(t, False, False, 0); tbox.pack_start(self.sub, False, False, 0)
        head.pack_start(tbox, True, True, 0)
        outer.pack_start(head, False, False, 0)

        self.card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.card.get_style_context().add_class("rs-card")
        self.state = Gtk.Label(label="", xalign=0); self.state.get_style_context().add_class("rs-ver")
        self.state.set_line_wrap(True)
        self.detail = Gtk.Label(label="", xalign=0); self.detail.get_style_context().add_class("rs-sub")
        self.detail.set_line_wrap(True)
        self.card.pack_start(self.state, False, False, 0)
        self.card.pack_start(self.detail, False, False, 0)
        self.progress = Gtk.ProgressBar(); self.progress.set_no_show_all(True); self.progress.hide()
        self.card.pack_start(self.progress, False, False, 0)
        outer.pack_start(self.card, False, False, 0)

        exp = Gtk.Expander(label="Details")
        self.logbuf = Gtk.TextBuffer()
        lv = Gtk.TextView(buffer=self.logbuf, editable=False, cursor_visible=False)
        lv.get_style_context().add_class("rs-log"); lv.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.logview = lv
        sc = Gtk.ScrolledWindow(); sc.set_min_content_height(120); sc.add(lv)
        exp.add(sc)
        outer.pack_start(exp, True, True, 0)

        btns = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        btns.set_halign(Gtk.Align.END)
        self.btn_check = Gtk.Button(label="Check for Updates"); self.btn_check.get_style_context().add_class("rs-btn")
        self.btn_check.connect("clicked", lambda *_: self.run("check"))
        self.btn_action = Gtk.Button(label="Update Now"); self.btn_action.get_style_context().add_class("rs-primary")
        self.btn_action.connect("clicked", lambda *_: self.run("apply"))
        self.btn_action.set_no_show_all(True); self.btn_action.hide()
        btns.pack_start(self.btn_check, False, False, 0)
        btns.pack_start(self.btn_action, False, False, 0)
        outer.pack_start(btns, False, False, 0)

        self.render(read_status())

    # ---- status rendering ----
    def render(self, st):
        chan = self._channel()
        self.sub.set_text("RedSword" + (f"  ·  {chan}" if chan else ""))
        rs = str(st.get("rs_update", 0)) == "1"
        others = int(st.get("total_upgrades", 0) or 0)
        checked = st.get("checked", "")
        when = self._ago(checked)
        if rs:
            self.state.set_markup(f"<span foreground='{MINT}'>A RedSword update is available</span>")
            self.detail.set_text(f"RedSword {st.get('rs_installed','?')} → {st.get('rs_candidate','?')}"
                                 + (f"   ·   {others} package(s) to update" if others else ""))
            self.btn_action.set_label("Update Now"); self.btn_action.show()
        elif others > 0:
            self.state.set_text(f"{others} system update(s) available")
            self.detail.set_text("RedSword itself is current; other packages can be updated.")
            self.btn_action.set_label("Update Everything"); self.btn_action.show()
        else:
            self.state.set_markup("<span class='rs-ok'>RedSword is up to date.</span>")
            self.state.get_style_context().add_class("rs-ok")
            self.detail.set_text("Last checked: " + (when or "never"))
            self.btn_action.hide()

    def _channel(self):
        try:
            for ln in open("/etc/redsword/update.conf"):
                if ln.strip().startswith("CHANNEL="):
                    return ln.split("=", 1)[1].strip().strip('"')
        except Exception:
            pass
        return ""

    def _ago(self, iso):
        try:
            t = datetime.datetime.strptime(iso, "%Y-%m-%dT%H:%M:%SZ")
            d = datetime.datetime.utcnow() - t
            s = int(d.total_seconds())
            if s < 90: return "just now"
            if s < 5400: return f"{s//60} min ago"
            if s < 172800: return f"{s//3600} hour(s) ago"
            return f"{s//86400} day(s) ago"
        except Exception:
            return ""

    # ---- running the root helper ----
    def run(self, action):
        if self.proc is not None:
            return
        self.btn_check.set_sensitive(False); self.btn_action.set_sensitive(False)
        self.logbuf.set_text("")
        self.progress.show(); self.progress.set_fraction(0)
        self._pulse = GLib.timeout_add(120, self._do_pulse)
        self.state.set_text("Checking for updates…" if action == "check" else "Updating…")
        self.detail.set_text("")
        argv = ["pkexec", ROOT_HELPER] + (["check"] if action == "check" else ["apply", "all"])
        try:
            self.proc = Gio.Subprocess.new(argv, Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_MERGE)
        except Exception as e:
            self._finish(f"Could not start updater: {e}"); return
        self.stream = Gio.DataInputStream.new(self.proc.get_stdout_pipe())
        self._next()
        self.proc.wait_async(None, self._done)

    def _do_pulse(self):
        self.progress.pulse(); return True

    def _next(self):
        self.stream.read_line_async(GLib.PRIORITY_DEFAULT, None, self._line)

    def _line(self, stream, res):
        try:
            line, _ = stream.read_line_finish_utf8(res)
        except Exception:
            line = None
        if line is None:
            return
        self._log(line + "\n")
        self._next()

    def _log(self, t):
        self.logbuf.insert(self.logbuf.get_end_iter(), t)
        m = self.logbuf.create_mark(None, self.logbuf.get_end_iter(), False)
        self.logview.scroll_mark_onscreen(m)

    def _done(self, proc, res):
        try:
            proc.wait_finish(res)
        except Exception:
            pass
        ok = (proc.get_exit_status() == 0) if hasattr(proc, "get_exit_status") else True
        self.proc = None
        self._finish(None if ok else "The update did not complete. See Details.")

    def _finish(self, err):
        if self._pulse:
            GLib.source_remove(self._pulse); self._pulse = None
        self.progress.hide()
        self.btn_check.set_sensitive(True); self.btn_action.set_sensitive(True)
        if err:
            self.state.set_text(err)
        else:
            self.render(read_status())
            buf = self.logbuf.get_text(self.logbuf.get_start_iter(), self.logbuf.get_end_iter(), False)
            if "RS-UPDATE-APPLIED" in buf:
                self.state.set_markup(f"<span foreground='{MINT}'>Update complete.</span>")
                self.detail.set_text("Some changes take effect after you log out or restart.")
                self.btn_action.hide()


def main():
    prov = Gtk.CssProvider(); prov.load_from_data(CSS.encode())
    Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), prov,
                                             Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    w = Updater(); w.connect("destroy", Gtk.main_quit); w.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
