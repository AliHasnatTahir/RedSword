#!/usr/bin/env python3
# RedSword Software — the App Center. A themed click-to-install store on top of the
# redsword box system (Debian/Ubuntu/Kali) and Flatpak/Flathub.
#
# Theme: onyx surfaces, mint (#3EB489) ONLY on the selected category, the search
# focus, and primary buttons; no green borders; solid smoky-black cards. App icon
# tiles use a muted per-app palette (never the reserved mint) when a themed icon
# is unavailable, so the grid stays lively without stealing the accent colour.
import json
import os
import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gio", "2.0")
from gi.repository import Gtk, Gdk, GLib, Gio, GdkPixbuf  # noqa: E402

MINT = "#3EB489"
LOGO = os.environ.get("REDSWORD_LOGO", "/usr/share/redsword/redsword-logo.png")
CATALOG = os.environ.get(
    "REDSWORD_CATALOG", "/usr/share/redsword/appcenter/catalog.json"
)
SIMULATE = os.environ.get("REDSWORD_SIMULATE", "") not in ("", "0", "false")
SIM_ENGINE = os.environ.get("REDSWORD_SIM_ENGINE", "")
AUTOSHOT = os.environ.get("REDSWORD_AUTOSHOT", "")
# Narrow root helper (validated args) that pkexec runs for install/remove.
HELPER = os.environ.get(
    "REDSWORD_APPCENTER_HELPER", "/usr/lib/redsword/appcenter/rs-appcenter-do")

BACKEND_LABEL = {"flatpak": "Flathub", "box": "{box} box", "apt": "System"}

CAT_ICON = {
    "Featured": "starred", "Internet": "applications-internet",
    "Development": "applications-development", "Security": "security-high",
    "Media": "applications-multimedia", "Graphics": "applications-graphics",
    "System": "applications-system", "Games": "applications-games",
    "Office": "applications-office", "Education": "applications-science",
}
CAT_BLURB = {
    "Featured": "Hand-picked apps to get you started",
    "Internet": "Browsers, email and chat",
    "Development": "Editors, languages and tools",
    "Security": "Ethical-hacking and pen-testing tools",
    "Media": "Play and create audio and video",
    "Graphics": "Design, photos and 3D",
    "System": "Utilities that keep things running",
}

# Icon-tile (bg, fg) pairs — richer than the chrome but deliberately NO greens, so
# the mint accent stays reserved for selection/primary. Tiles are app-icon content
# (like the colourful Slot icons on the dock), not UI chrome.
TILE_PALETTE = [
    ((0.17, 0.27, 0.44), (0.97, 0.98, 1.00)),   # blue
    ((0.31, 0.24, 0.42), (0.98, 0.96, 1.00)),   # violet
    ((0.12, 0.30, 0.45), (0.95, 0.99, 1.00)),   # azure
    ((0.42, 0.30, 0.15), (1.00, 0.97, 0.92)),   # amber
    ((0.42, 0.19, 0.25), (1.00, 0.95, 0.96)),   # rose
    ((0.22, 0.25, 0.46), (0.97, 0.97, 1.00)),   # indigo
    ((0.28, 0.30, 0.35), (1.00, 1.00, 1.00)),   # slate
]

CSS = f"""
window, .rs-root {{ background-color: #131313; color: #e8e8e8; }}
.rs-header {{ background-color: #171717; border-bottom: 1px solid #242424; }}
.rs-title {{ font-size: 19px; font-weight: 800; color: #ffffff; }}
.rs-appname {{ font-size: 14px; font-weight: 700; color: #f3f3f3; }}
.rs-summary {{ font-size: 12px; color: #9a9a9a; }}
.rs-tag {{ font-size: 10px; font-weight: 700; color: #6f6f6f; letter-spacing: .4px; }}
.rs-sidebar {{ background-color: #0f0f0f; }}
.rs-cat row {{ padding: 2px 8px; }}
.rs-cat-label {{ color: #a0a0a0; font-size: 13px; font-weight: 600; }}
.rs-cat row:selected {{ background-color: {MINT}; border-radius: 9px; }}
.rs-cat row:selected .rs-cat-label {{ color: #08130f; font-weight: 800; }}
.rs-card {{ background-color: #1b1b1b; border-radius: 14px; }}
.rs-card:hover {{ background-color: #232323; }}
.rs-section {{ font-size: 20px; font-weight: 800; color: #f2f2f2; }}
.rs-section-sub {{ font-size: 12px; color: #8a8a8a; }}
.rs-count {{ font-size: 12px; color: #6f6f6f; }}
entry, .rs-search {{ background-color: #1f1f1f; color: #f0f0f0; border: 1px solid #2a2a2a;
        border-radius: 10px; padding: 7px 10px; }}
entry:focus, .rs-search:focus-within {{ border-color: {MINT}; }}
.rs-btn {{ background-image: none; background-color: #2a2a2a; color: #ededed;
          border: none; border-radius: 9px; padding: 7px 18px; font-weight: 700; }}
.rs-btn:hover {{ background-color: #343434; }}
.rs-btn:disabled {{ color: #5a5a5a; background-color: #191919; }}
.rs-btn-primary {{ background-image: none; background-color: {MINT}; color: #08130f;
                  border-radius: 9px; padding: 7px 18px; font-weight: 800; }}
.rs-btn-primary:hover {{ background-color: #4bcfa1; }}
.rs-btn-primary:disabled {{ background-color: #24332d; color: #4d6a5e; }}
.rs-installed {{ color: {MINT}; font-weight: 800; font-size: 12px; }}
.rs-activity {{ background-color: #0f0f0f; border-top: 1px solid #242424; }}
.rs-activity-title {{ color: #ededed; font-weight: 700; }}
progressbar trough {{ background-color: #202020; border: none; border-radius: 6px;
                     min-height: 7px; }}
progressbar progress {{ background-color: {MINT}; border: none; border-radius: 6px;
                       min-height: 7px; }}
.rs-log {{ background-color: #0b0b0b; color: #9fdcc4; font-family: monospace;
          font-size: 11px; padding: 8px; border-radius: 8px; }}
.rs-muted {{ color: #8a8a8a; }}
"""

DEFAULT_CATALOG = {
    "categories": ["Featured", "Internet", "Security", "System"],
    "apps": [
        {"id": "nmap", "name": "Nmap", "summary": "Network scanner",
         "category": "Security", "icon": "utilities-terminal", "featured": True,
         "backend": "box", "box": "kali", "ref": "nmap"},
    ],
}

REQUIRED_KEYS = ("id", "name", "backend", "ref")


def load_catalog():
    for path in (CATALOG, os.path.join(os.path.dirname(__file__), "catalog.json")):
        try:
            with open(path) as f:
                return json.load(f)
        except Exception:
            continue
    return DEFAULT_CATALOG


class AppCenter(Gtk.Window):
    def __init__(self):
        super().__init__(title="RedSword Software")
        self.set_default_size(1040, 700)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.get_style_context().add_class("rs-root")
        try:
            settings = Gtk.Settings.get_default()
            settings.set_property("gtk-application-prefer-dark-theme", True)
            if os.path.isdir("/usr/share/icons/Slot"):
                settings.set_property("gtk-icon-theme-name", "Slot")
        except Exception:
            pass

        self.catalog = load_catalog()
        # keep only well-formed entries so one bad row can't crash the render
        self.apps = [a for a in self.catalog.get("apps", [])
                     if isinstance(a, dict) and all(k in a for k in REQUIRED_KEYS)]
        self.categories = self.catalog.get("categories", ["Featured"])
        self.installed = set()
        self.busy = False
        self.proc = None
        self.current_cat = "Featured"
        self.query = ""
        self.card_widgets = []

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(root)
        root.pack_start(self._header(), False, False, 0)

        body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        body.set_vexpand(True)
        root.pack_start(body, True, True, 0)
        content_w = self._content()        # build content first (see _on_cat)
        sidebar_w = self._sidebar()
        body.pack_start(sidebar_w, False, False, 0)
        body.pack_start(content_w, True, True, 0)

        root.pack_start(self._activity_bar(), False, False, 0)

        self._detect_installed()
        self._render_apps()

        if AUTOSHOT:
            GLib.timeout_add(700, self._autopilot_start)

    # ---- chrome ---------------------------------------------------------
    def _logo(self, px):
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(LOGO, px, px, True)
            return Gtk.Image.new_from_pixbuf(pb)
        except Exception:
            return Gtk.Image.new_from_icon_name("system-software-install",
                                                Gtk.IconSize.DIALOG)

    def _header(self):
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        bar.get_style_context().add_class("rs-header")
        bar.set_border_width(14)
        bar.pack_start(self._logo(28), False, False, 0)
        t = Gtk.Label(label="RedSword Software")
        t.get_style_context().add_class("rs-title")
        bar.pack_start(t, False, False, 0)
        self.search = Gtk.SearchEntry()
        self.search.set_placeholder_text("Search apps and tools…")
        self.search.set_size_request(300, -1)
        self.search.connect("search-changed", self._on_search)
        bar.pack_end(self.search, False, False, 0)
        return bar

    def _sidebar(self):
        self.cat_list = Gtk.ListBox()
        self.cat_list.get_style_context().add_class("rs-cat")
        self.cat_list.get_style_context().add_class("rs-sidebar")
        self.cat_list.set_size_request(196, -1)
        self.cat_list.set_selection_mode(Gtk.SelectionMode.SINGLE)
        theme = Gtk.IconTheme.get_default()
        for c in self.categories:
            row = Gtk.ListBoxRow()
            row.cat = c
            hb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            hb.set_border_width(7)
            icon_name = CAT_ICON.get(c, "folder")
            if not theme.has_icon(icon_name):
                icon_name = "folder"
            img = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU)
            hb.pack_start(img, False, False, 0)
            lab = Gtk.Label(label=c, xalign=0)
            lab.get_style_context().add_class("rs-cat-label")
            hb.pack_start(lab, True, True, 0)
            row.add(hb)
            self.cat_list.add(row)
        self.cat_list.connect("row-selected", self._on_cat)
        self.cat_list.select_row(self.cat_list.get_row_at_index(0))
        frame = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        frame.get_style_context().add_class("rs-sidebar")
        frame.set_border_width(8)
        frame.pack_start(self.cat_list, True, True, 0)
        return frame

    def _content(self):
        self.applist = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.applist.set_border_width(22)
        sc = Gtk.ScrolledWindow()
        sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sc.add(self.applist)
        return sc

    def _activity_bar(self):
        self.activity = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.activity.get_style_context().add_class("rs-activity")
        self.activity.set_border_width(14)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.activity_spinner = Gtk.Spinner()
        row.pack_start(self.activity_spinner, False, False, 0)
        self.activity_label = Gtk.Label(label="", xalign=0)
        self.activity_label.get_style_context().add_class("rs-activity-title")
        self.activity_label.set_hexpand(True)
        row.pack_start(self.activity_label, True, True, 0)
        self.activity_bar = Gtk.ProgressBar()
        self.activity_bar.set_size_request(280, -1)
        self.activity_bar.set_valign(Gtk.Align.CENTER)
        row.pack_start(self.activity_bar, False, False, 0)
        self.activity.pack_start(row, False, False, 0)

        exp = Gtk.Expander(label="Show details")
        self.log_view = Gtk.TextView(editable=False, cursor_visible=False)
        self.log_view.get_style_context().add_class("rs-log")
        self.log_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.log_buffer = self.log_view.get_buffer()
        lsc = Gtk.ScrolledWindow()
        lsc.set_min_content_height(120)
        lsc.add(self.log_view)
        exp.add(lsc)
        self.activity.pack_start(exp, False, False, 0)
        self.activity.set_no_show_all(True)
        self.activity.hide()
        return self.activity

    # ---- rendering ------------------------------------------------------
    def _visible_apps(self):
        q = self.query.lower().strip()
        out = []
        for a in self.apps:
            if q:
                hay = (a.get("name", "") + " " + a.get("summary", "") + " "
                       + a.get("category", "")).lower()
                if q in hay:
                    out.append(a)
            elif self.current_cat == "Featured":
                if a.get("featured"):
                    out.append(a)
            elif a.get("category") == self.current_cat:
                out.append(a)
        return out

    def _render_apps(self):
        if not hasattr(self, "applist"):
            return
        for c in self.applist.get_children():
            self.applist.remove(c)
        self.card_widgets = []

        apps = self._visible_apps()

        # section header: big title + subtitle + count
        head = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        title = Gtk.Label(xalign=0)
        title.get_style_context().add_class("rs-section")
        searching = bool(self.query.strip())
        title.set_text(f"Results for “{self.query.strip()}”" if searching
                       else self.current_cat)
        title_row.pack_start(title, False, False, 0)
        count = Gtk.Label(xalign=0)
        count.get_style_context().add_class("rs-count")
        count.set_valign(Gtk.Align.END)
        count.set_margin_bottom(3)
        count.set_text(f"{len(apps)} app" + ("" if len(apps) == 1 else "s"))
        title_row.pack_start(count, False, False, 0)
        head.pack_start(title_row, False, False, 0)
        blurb = (CAT_BLURB.get(self.current_cat, "") if not searching else "")
        if blurb:
            sub = Gtk.Label(label=blurb, xalign=0)
            sub.get_style_context().add_class("rs-section-sub")
            head.pack_start(sub, False, False, 0)
        head.set_margin_bottom(6)
        self.applist.pack_start(head, False, False, 0)

        if not apps:
            empty = Gtk.Label(
                label=("No results — try another word." if searching
                       else "No apps in this category yet."), xalign=0)
            empty.get_style_context().add_class("rs-muted")
            self.applist.pack_start(empty, False, False, 0)
            self.applist.show_all()
            return

        for a in apps:
            self.applist.pack_start(self._app_card(a), False, False, 0)
        self.applist.show_all()
        self._refresh_buttons()

    # ---- icon tiles -----------------------------------------------------
    def _tile_colors(self, key):
        idx = sum(ord(c) for c in (key or "?")) % len(TILE_PALETTE)
        return TILE_PALETTE[idx]

    def _app_tile(self, a, px=52):
        # Prefer a real themed icon ONLY when it genuinely loads at this size
        # (has_icon() lies in the Slot theme — brand names resolve then fail to
        # load), otherwise draw a clean coloured initial tile for a uniform grid.
        theme = Gtk.IconTheme.get_default()
        name = a.get("icon", "")
        if name:
            try:
                pb = theme.load_icon(name, px, Gtk.IconLookupFlags.FORCE_SIZE)
                if pb is not None:
                    img = Gtk.Image.new_from_pixbuf(pb)
                    img.set_size_request(px, px)
                    return img
            except Exception:
                pass
        da = Gtk.DrawingArea()
        da.set_size_request(px, px)
        letter = ((a.get("name", "?").strip() or "?")[0]).upper()
        bg, fg = self._tile_colors(a.get("id") or a.get("name", ""))
        da.connect("draw", self._draw_tile, letter, bg, fg)
        return da

    def _draw_tile(self, widget, cr, letter, bg, fg):
        alloc = widget.get_allocation()
        w, h = alloc.width, alloc.height
        r = max(8, int(min(w, h) * 0.26))
        # rounded rectangle
        cr.new_sub_path()
        cr.arc(w - r, r, r, -1.5708, 0)
        cr.arc(w - r, h - r, r, 0, 1.5708)
        cr.arc(r, h - r, r, 1.5708, 3.14159)
        cr.arc(r, r, r, 3.14159, 4.71239)
        cr.close_path()
        cr.set_source_rgb(*bg)
        cr.fill_preserve()
        # faint top sheen for a little depth
        cr.set_source_rgba(1, 1, 1, 0.05)
        cr.fill()
        # centred initial
        cr.select_font_face("Sans", 0, 1)  # normal slant, bold
        cr.set_font_size(h * 0.5)
        cr.set_source_rgb(*fg)
        ext = cr.text_extents(letter)
        cr.move_to(w / 2 - (ext.width / 2 + ext.x_bearing),
                   h / 2 - (ext.height / 2 + ext.y_bearing))
        cr.show_text(letter)
        return False

    def _app_card(self, a):
        ev = Gtk.EventBox()
        ev.get_style_context().add_class("rs-card")
        card = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        card.set_border_width(13)
        ev.add(card)

        card.pack_start(self._app_tile(a, 52), False, False, 0)

        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        text.set_valign(Gtk.Align.CENTER)
        text.set_hexpand(True)
        name = Gtk.Label(label=a.get("name", "?"), xalign=0)
        name.get_style_context().add_class("rs-appname")
        summ = Gtk.Label(label=a.get("summary", ""), xalign=0)
        summ.get_style_context().add_class("rs-summary")
        summ.set_line_wrap(True)
        summ.set_max_width_chars(60)
        tag = Gtk.Label(xalign=0)
        tag.get_style_context().add_class("rs-tag")
        tag.set_text(BACKEND_LABEL.get(a["backend"], a["backend"]).format(
            box=a.get("box", "")).upper())
        text.pack_start(name, False, False, 0)
        text.pack_start(summ, False, False, 0)
        text.pack_start(tag, False, False, 0)
        card.pack_start(text, True, True, 0)

        status = Gtk.Label(xalign=1)
        status.get_style_context().add_class("rs-installed")
        status.set_valign(Gtk.Align.CENTER)
        card.pack_end(status, False, False, 0)

        btn = Gtk.Button()
        btn.set_valign(Gtk.Align.CENTER)
        btn.set_size_request(104, -1)
        btn.get_style_context().add_class("rs-btn-primary")
        btn.connect("clicked", self._on_action, a)
        card.pack_end(btn, False, False, 0)

        self.card_widgets.append((a, btn, status))
        return ev

    def _refresh_buttons(self):
        for a, btn, status in self.card_widgets:
            inst = a["id"] in self.installed
            ctx = btn.get_style_context()
            if inst:
                btn.set_label("Remove")
                ctx.remove_class("rs-btn-primary")
                ctx.add_class("rs-btn")
                status.set_text("✓ Installed")
            else:
                btn.set_label("Get")
                ctx.remove_class("rs-btn")
                ctx.add_class("rs-btn-primary")
                status.set_text("")
            btn.set_sensitive(not self.busy)

    # ---- events ---------------------------------------------------------
    def _on_cat(self, _list, row):
        if row is None:
            return
        self.current_cat = row.cat
        if self.search.get_text():
            self.search.set_text("")     # fires _on_search -> single render
        else:
            self.query = ""
            self._render_apps()

    def _on_search(self, entry):
        self.query = entry.get_text()
        self._render_apps()

    def _on_action(self, _btn, a):
        if self.busy:
            return
        remove = a["id"] in self.installed
        self._run_backend(a, remove)

    # ---- install/remove backends ---------------------------------------
    def _detect_installed(self):
        if SIMULATE:
            return
        # One `flatpak list` instead of one `flatpak info` per app (was ~11 slow
        # subprocess calls freezing startup); box/apt checks are cheap file lookups.
        flatpak_have = set()
        try:
            out = _out(["flatpak", "list", "--app", "--columns=application"])
            flatpak_have = {ln.strip() for ln in out.splitlines() if ln.strip()}
        except Exception:
            pass
        for a in self.apps:
            try:
                if a["backend"] == "flatpak":
                    if a["ref"] in flatpak_have:
                        self.installed.add(a["id"])
                elif a["backend"] == "box":
                    ref, box = a["ref"], a.get("box", "")
                    if (os.path.exists(f"/usr/local/bin/{ref}") or _glob_exists(
                            f"/usr/share/applications/redsword-{box}-*{ref}*.desktop")):
                        self.installed.add(a["id"])
                elif a["backend"] == "apt":
                    if _run(["dpkg-query", "-W", a["ref"]]) == 0:
                        self.installed.add(a["id"])
            except Exception:
                pass

    def _argv(self, a, remove):
        verb = "remove" if remove else "install"
        if SIMULATE and SIM_ENGINE:
            return ["bash", SIM_ENGINE, verb, a["name"]]
        box = a.get("box", "-")
        return ["pkexec", HELPER, a["backend"], verb, box, a["ref"]]

    def _set_controls_enabled(self, enabled):
        self.cat_list.set_sensitive(enabled)
        self.search.set_sensitive(enabled)

    def _run_backend(self, a, remove):
        self.busy = True
        self._set_controls_enabled(False)
        self._refresh_buttons()
        self._active_app = a
        self._active_remove = remove
        verb = "Removing" if remove else "Installing"
        self.activity_label.set_text(f"{verb} {a['name']}…")
        self.activity_bar.set_fraction(0.0)
        self.log_buffer.set_text("")
        # no_show_all keeps the bar hidden at startup; lift it so show_all reveals
        # the spinner/label/progress (otherwise the bar shows as an empty sliver).
        self.activity.set_no_show_all(False)
        self.activity.show_all()
        self.activity_spinner.start()

        argv = self._argv(a, remove)
        self._pulse_id = GLib.timeout_add(120, self._pulse)
        try:
            self.proc = Gio.Subprocess.new(
                argv, Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_MERGE)
        except Exception as e:
            self._log(f"could not start: {e}\n")
            self._backend_done_ui(False)
            return
        self.data_stream = Gio.DataInputStream.new(self.proc.get_stdout_pipe())
        self._read_next()
        self.proc.wait_async(None, self._on_backend_done)

    def _pulse(self):
        self.activity_bar.pulse()
        return True

    def _read_next(self):
        self.data_stream.read_line_async(GLib.PRIORITY_DEFAULT, None, self._on_line)

    def _on_line(self, stream, res):
        try:
            line, _ = stream.read_line_finish_utf8(res)
        except Exception:
            line = None
        if line is None:
            return
        self._log(line + "\n")
        self._read_next()

    def _log(self, text):
        end = self.log_buffer.get_end_iter()
        self.log_buffer.insert(end, text)
        mark = self.log_buffer.create_mark(None, self.log_buffer.get_end_iter(), False)
        self.log_view.scroll_mark_onscreen(mark)

    def _on_backend_done(self, proc, res):
        if getattr(self, "_pulse_id", None):
            GLib.source_remove(self._pulse_id)
            self._pulse_id = None
        try:
            proc.wait_finish(res)
        except Exception:
            pass
        ok = proc.get_successful() if hasattr(proc, "get_successful") else (
            proc.get_exit_status() == 0)
        self._backend_done_ui(ok)

    def _backend_done_ui(self, ok):
        self.activity_spinner.stop()
        a = self._active_app
        if ok:
            if self._active_remove:
                self.installed.discard(a["id"])
                self.activity_label.set_text(f"Removed {a['name']}")
            else:
                self.installed.add(a["id"])
                self.activity_label.set_text(f"Installed {a['name']}  ✓")
            self.activity_bar.set_fraction(1.0)
        else:
            self.activity_label.set_text(
                f"Could not {'remove' if self._active_remove else 'install'} "
                f"{a['name']} — see details.")
            self.activity_bar.set_fraction(0.0)
        self.proc = None
        self.busy = False
        self._set_controls_enabled(True)
        self._refresh_buttons()
        if not AUTOSHOT:
            GLib.timeout_add_seconds(4, self._maybe_hide_activity)

    def _maybe_hide_activity(self):
        if not self.busy:
            self.activity.hide()
            self.activity.set_no_show_all(True)
        return False

    # ---- autopilot (test only) -----------------------------------------
    def _shot(self, name):
        win = self.get_window()
        if win is None:
            return
        w, h = self.get_size()
        pb = Gdk.pixbuf_get_from_window(win, 0, 0, w, h)
        if pb:
            path = f"{AUTOSHOT}/appcenter-{name}.png"
            pb.savev(path, "png", [], [])
            print(f"shot {path}", flush=True)

    def _autopilot_start(self):
        self._shot("1-featured")
        for i, c in enumerate(self.categories):
            if c == "Security":
                self.cat_list.select_row(self.cat_list.get_row_at_index(i))
                break
        GLib.timeout_add(500, self._auto_after_cat)
        return False

    def _auto_after_cat(self):
        self._shot("2-security")
        if self.card_widgets:
            a, btn, _ = self.card_widgets[0]
            self._on_action(btn, a)
            GLib.timeout_add(500, lambda: (self._shot("3-installing"), False)[1])
            GLib.timeout_add(5000, self._auto_after_install)
        else:
            GLib.timeout_add(500, Gtk.main_quit)
        return False

    def _auto_after_install(self):
        self._shot("4-installed")
        self.search.set_text("wire")
        GLib.timeout_add(500, lambda: (self._shot("5-search"),
                                       GLib.timeout_add(400, Gtk.main_quit),
                                       False)[2])
        return False


def _run(argv):
    import subprocess
    try:
        return subprocess.call(argv, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL)
    except Exception:
        return 1


def _out(argv):
    import subprocess
    return subprocess.check_output(argv, text=True, stderr=subprocess.DEVNULL)


def _glob_exists(pattern):
    import glob
    return bool(glob.glob(pattern))


def main():
    provider = Gtk.CssProvider()
    provider.load_from_data(CSS.encode())
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    win = AppCenter()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
