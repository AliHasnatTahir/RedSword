#!/usr/bin/env python3
# RedSword Control Center — top-bar quick-settings popup, matched to the decided
# design prototype: smoky-black borderless card; 2x2 tiles each with an
# icon-in-rounded-square (mint ONLY when active) + label + sub-label; two mint
# sliders; footer "RedSword · <net>  ·  All settings ›". Toggles drive real state
# where the tools exist and degrade gracefully.
import math
import os
import subprocess
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib  # noqa: E402

MINT = (0.243, 0.706, 0.541)      # #3EB489
INK = (0.016, 0.071, 0.047)       # dark ink on mint
FAINT = (0.39, 0.46, 0.43)        # faint glyph when off
AUTOSHOT = os.environ.get("REDSWORD_AUTOSHOT", "")

CSS = """
window, .cc { background-color: #141416; color: #e9f2ee; }
.cc { border-radius: 13px; }
.tile { background-color: rgba(255,255,255,0.05); border-radius: 11px; }
.tile:hover { background-color: rgba(255,255,255,0.09); }
.tile-lbl { font-size: 11.5px; font-weight: 700; color: #eef5f1; }
.tile-sub { font-size: 9.5px; color: #93a8a0; }
scale trough { background-color: rgba(255,255,255,0.12); border: none; border-radius: 3px; min-height: 6px; }
scale highlight { background-color: #3EB489; border: none; border-radius: 3px; }
scale slider { background-color: #eafaf3; border: none; border-radius: 50%; min-width: 14px; min-height: 14px; margin: -5px; }
.slider-icon { color: #93a8a0; }
.foot { border-top: 1px solid rgba(255,255,255,0.08); }
.foot-lbl { font-size: 11px; color: #93a8a0; }
.foot button { background: transparent; border: none; color: #e9f2ee; padding: 2px 4px; }
.foot button:hover { color: #57D6A6; }
"""


def sh(*a):
    try:
        return subprocess.run(a, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                              text=True, timeout=4).stdout.strip()
    except Exception:
        return ""


def sh_ok(*a):
    try:
        return subprocess.call(a, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL) == 0
    except Exception:
        return False


# ---- glyph painters (drawn on the icon square) ----------------------------
def g_wifi(cr, s, c):
    cr.set_source_rgb(*c)
    cr.set_line_width(max(1.4, s * 0.08))
    cr.set_line_cap(cairo_round())
    cx, cy = s / 2, s * 0.66
    for i, r in enumerate((s * 0.14, s * 0.26, s * 0.38)):
        cr.arc(cx, cy, r, math.radians(212), math.radians(328))
        cr.stroke()
    cr.arc(cx, cy, s * 0.03, 0, 2 * math.pi)
    cr.fill()


def g_bt(cr, s, c):
    cr.set_source_rgb(*c)
    cr.set_line_width(max(1.4, s * 0.08))
    cr.set_line_join(cairo_round_join())
    cr.set_line_cap(cairo_round())
    x, top, bot, mid = s * 0.5, s * 0.22, s * 0.78, s * 0.5
    l, r = s * 0.33, s * 0.67
    cr.move_to(l, s * 0.36); cr.line_to(r, s * 0.64)
    cr.line_to(x, bot); cr.line_to(x, top)
    cr.line_to(r, s * 0.36); cr.line_to(l, s * 0.64)
    cr.stroke()


def g_shield(cr, s, c, check=False):
    cr.set_source_rgb(*c)
    cr.set_line_width(max(1.4, s * 0.08))
    cr.set_line_join(cairo_round_join())
    cx = s / 2
    cr.move_to(cx, s * 0.16)
    cr.line_to(s * 0.78, s * 0.28)
    cr.line_to(s * 0.78, s * 0.52)
    cr.curve_to(s * 0.78, s * 0.72, s * 0.64, s * 0.8, cx, s * 0.86)
    cr.curve_to(s * 0.36, s * 0.8, s * 0.22, s * 0.72, s * 0.22, s * 0.52)
    cr.line_to(s * 0.22, s * 0.28)
    cr.close_path()
    cr.stroke()
    if check:
        cr.move_to(s * 0.40, s * 0.50); cr.line_to(s * 0.47, s * 0.58)
        cr.line_to(s * 0.62, s * 0.40); cr.stroke()


def g_power(cr, s, c):
    cr.set_source_rgb(*c)
    cr.set_line_width(max(1.4, s * 0.08))
    cr.set_line_cap(cairo_round())
    cx, cy = s / 2, s * 0.54
    cr.arc(cx, cy, s * 0.26, math.radians(300), math.radians(240))
    cr.stroke()
    cr.move_to(cx, s * 0.2); cr.line_to(cx, s * 0.48); cr.stroke()


def cairo_round():
    import cairo
    return cairo.LINE_CAP_ROUND


def cairo_round_join():
    import cairo
    return cairo.LINE_JOIN_ROUND


GLYPHS = {"wifi": g_wifi, "bt": g_bt, "vpn": g_power,
          "toolkit": lambda cr, s, c: g_shield(cr, s, c, check=True)}


class ControlCenter(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_default_size(290, -1)
        self.set_skip_taskbar_hint(True)
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.get_style_context().add_class("cc")
        try:
            Gtk.Settings.get_default().set_property(
                "gtk-application-prefer-dark-theme", True)
        except Exception:
            pass
        self._armed = False
        if not AUTOSHOT:
            self.connect("focus-out-event", self._on_focus_out)
            self.connect("key-press-event", self._on_key)
            GLib.timeout_add(500, self._arm)

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=7)
        outer.set_border_width(13)
        self.add(outer)

        grid = Gtk.Grid(column_spacing=8, row_spacing=8)
        grid.set_column_homogeneous(True)
        self.tiles = {}
        specs = [
            ("wifi", "Wi-Fi", self._wifi_state, self._wifi_sub, self._wifi_set),
            ("bt", "Bluetooth", self._bt_state, lambda: "On", self._bt_set),
            ("vpn", "VPN", lambda: False, lambda: "Off", None),
            ("toolkit", "Toolkit Mode", lambda: True, lambda: "Active", None),
        ]
        for i, (key, label, get, sub, setter) in enumerate(specs):
            grid.attach(self._tile(key, label, get(), sub(), setter),
                        i % 2, i // 2, 1, 1)
        outer.pack_start(grid, False, False, 0)

        outer.pack_start(self._slider("vol", self._vol_get(), self._vol_set),
                         False, False, 0)
        outer.pack_start(self._slider("bright", self._bright_get(), self._bright_set),
                         False, False, 0)
        outer.pack_start(self._footer(), False, False, 0)

        if AUTOSHOT:
            GLib.timeout_add(600, self._shot)

    # ---- tiles ----------------------------------------------------------
    def _tile(self, key, label, on, sub, setter):
        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.get_style_context().add_class("tile")
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=9)
        row.set_border_width(9)
        da = Gtk.DrawingArea()
        da.set_size_request(28, 28)
        da.connect("draw", self._draw_ci, key)
        row.pack_start(da, False, False, 0)
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        col.set_valign(Gtk.Align.CENTER)
        lbl = Gtk.Label(label=label, xalign=0)
        lbl.get_style_context().add_class("tile-lbl")
        subl = Gtk.Label(label=sub, xalign=0)
        subl.get_style_context().add_class("tile-sub")
        col.pack_start(lbl, False, False, 0)
        col.pack_start(subl, False, False, 0)
        row.pack_start(col, True, True, 0)
        btn.add(row)
        self.tiles[key] = {"on": on, "sub": subl, "da": da,
                           "sub_on": sub, "setter": setter}
        btn.connect("clicked", self._toggle, key)
        return btn

    def _draw_ci(self, widget, cr, key):
        s = 28
        r = 8
        # rounded square background
        cr.new_sub_path()
        cr.arc(s - r, r, r, -math.pi / 2, 0)
        cr.arc(s - r, s - r, r, 0, math.pi / 2)
        cr.arc(r, s - r, r, math.pi / 2, math.pi)
        cr.arc(r, r, r, math.pi, 3 * math.pi / 2)
        cr.close_path()
        on = self.tiles[key]["on"]
        cr.set_source_rgb(*(MINT if on else (0.12, 0.12, 0.13)))
        cr.fill()
        GLYPHS[key](cr, s, INK if on else FAINT)
        return False

    def _toggle(self, _btn, key):
        t = self.tiles[key]
        t["on"] = not t["on"]
        t["da"].queue_draw()
        t["sub"].set_text(t["sub_on"]() if t["on"] else "Off")
        if t["setter"]:
            t["setter"](t["on"])

    # ---- sliders --------------------------------------------------------
    def _slider(self, kind, value, setter):
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.get_style_context().add_class("tile")
        row.set_border_width(8)
        da = Gtk.DrawingArea()
        da.set_size_request(16, 16)
        da.connect("draw", self._draw_slider_icon, kind)
        row.pack_start(da, False, False, 2)
        sc = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        sc.set_draw_value(False)
        sc.set_value(value)
        sc.set_hexpand(True)
        sc.connect("value-changed", lambda w: setter(int(w.get_value())))
        row.pack_start(sc, True, True, 0)
        return row

    def _draw_slider_icon(self, widget, cr, kind):
        s = 16
        cr.set_source_rgb(*FAINT)
        cr.set_line_width(1.5)
        cr.set_line_cap(cairo_round())
        cr.set_line_join(cairo_round_join())
        if kind == "vol":
            cr.move_to(s * 0.2, s * 0.38); cr.line_to(s * 0.2, s * 0.62)
            cr.line_to(s * 0.4, s * 0.62); cr.line_to(s * 0.6, s * 0.8)
            cr.line_to(s * 0.6, s * 0.2); cr.line_to(s * 0.4, s * 0.38)
            cr.close_path(); cr.stroke()
            cr.arc(s * 0.62, s * 0.5, s * 0.22, math.radians(-55), math.radians(55))
            cr.stroke()
        else:
            cr.arc(s / 2, s / 2, s * 0.24, 0, 2 * math.pi); cr.stroke()
            for a in range(0, 360, 45):
                x = s / 2 + math.cos(math.radians(a)) * s * 0.36
                y = s / 2 + math.sin(math.radians(a)) * s * 0.36
                x2 = s / 2 + math.cos(math.radians(a)) * s * 0.30
                y2 = s / 2 + math.sin(math.radians(a)) * s * 0.30
                cr.move_to(x2, y2); cr.line_to(x, y); cr.stroke()
        return False

    # ---- footer ---------------------------------------------------------
    def _footer(self):
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        box.get_style_context().add_class("foot")
        box.set_margin_top(4)
        left = Gtk.Label(xalign=0)
        left.get_style_context().add_class("foot-lbl")
        left.set_text(f"RedSword · {self._net_label()}")
        left.set_margin_top(8)
        box.pack_start(left, True, True, 0)
        btn = Gtk.Button(label="All settings ›")
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.get_style_context().add_class("foot-lbl")
        btn.set_margin_top(4)
        btn.connect("clicked", lambda *_: self._settings())
        box.pack_end(btn, False, False, 0)
        return box

    def _net_label(self):
        iface = sh("sh", "-c", "ip route 2>/dev/null | awk '/^default/{print $5; exit}'")
        return f"{iface} connected" if iface else "offline"

    # ---- helpers / state ------------------------------------------------
    def _arm(self):
        self._armed = True
        return False

    def _on_focus_out(self, *_):
        if self._armed:
            self.close()
        return False

    def _on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self.close()

    def _wifi_state(self):
        return sh("nmcli", "-t", "radio", "wifi") == "enabled"

    def _wifi_sub(self):
        ssid = sh("sh", "-c",
                  "nmcli -t -f active,ssid dev wifi 2>/dev/null | awk -F: '/^yes/{print $2; exit}'")
        return ssid or "On"

    def _wifi_set(self, on):
        sh_ok("nmcli", "radio", "wifi", "on" if on else "off")

    def _bt_state(self):
        return "Powered: yes" in sh("bluetoothctl", "show")

    def _bt_set(self, on):
        sh_ok("bluetoothctl", "power", "on" if on else "off")

    def _vol_get(self):
        out = sh("pactl", "get-sink-volume", "@DEFAULT_SINK@")
        for tok in out.replace("/", " ").split():
            if tok.endswith("%"):
                try:
                    return int(tok[:-1])
                except ValueError:
                    pass
        return 70

    def _vol_set(self, v):
        sh_ok("pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{v}%")

    def _bright_get(self):
        cur, mx = sh("brightnessctl", "g"), sh("brightnessctl", "m")
        try:
            return int(int(cur) * 100 / int(mx))
        except Exception:
            return 48

    def _bright_set(self, v):
        sh_ok("brightnessctl", "s", f"{v}%")

    def _settings(self):
        for c in (["xfce4-settings-manager"], ["redsword-software"]):
            if sh_ok("which", c[0]):
                subprocess.Popen(c)
                break
        if not AUTOSHOT:
            self.close()

    def _shot(self):
        win = self.get_window()
        if win is None:
            return
        w, h = self.get_size()
        pb = Gdk.pixbuf_get_from_window(win, 0, 0, w, h)
        if pb:
            path = f"{AUTOSHOT}/control-center.png"
            pb.savev(path, "png", [], [])
            print(f"shot {path}", flush=True)
        GLib.timeout_add(300, Gtk.main_quit)


def main():
    provider = Gtk.CssProvider()
    provider.load_from_data(CSS.encode())
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    win = ControlCenter()
    win.connect("destroy", Gtk.main_quit)
    win.set_position(Gtk.WindowPosition.CENTER if AUTOSHOT
                     else Gtk.WindowPosition.MOUSE)
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
