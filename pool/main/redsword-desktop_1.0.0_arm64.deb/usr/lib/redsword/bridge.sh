# shellcheck shell=bash
# RedSword bridge: make apps installed in a box appear on the host like normal apps.
# Exports .desktop launchers + icons from a box to the host, rewriting each launcher
# so it starts through redsword-run (which gives the app the screen + the user's files).

RS_APPS_DIR=${RS_APPS_DIR:-/usr/share/applications}
RS_ICONS_DIR=${RS_ICONS_DIR:-/usr/share/icons}
RS_RUN=/usr/libexec/redsword-run
RS_STAMP_KEY=X-RedSword-Box

# Rewrite one .desktop file so its Exec/TryExec run inside the box, and tag it.
_rs_rewrite_desktop(){
    local box=$1 src=$2 dst=$3
    awk -v box="$box" -v run="$RS_RUN" '
        BEGIN{IGNORECASE=0}
        /^Exec=/    { sub(/^Exec=/,   "Exec="   run " " box " "); print; next }
        /^TryExec=/ { next }  # drop TryExec: the binary lives in the box, not on the host
        /^DBusActivatable=/ { next }
        { print }
        END{ print "X-RedSword-Box=" box }
    ' "$src" > "$dst"
}

# Export every app from a box to the host menu. Pass a list of changed .desktop basenames,
# or nothing to export them all.
rs_bridge_export(){
    local box=$1; shift
    local dir; dir=$(rs_box_dir "$box")
    local boxapps="$dir/usr/share/applications"
    [ -d "$boxapps" ] || return 0
    mkdir -p "$RS_APPS_DIR"

    local count=0 f base
    for f in "$boxapps"/*.desktop; do
        [ -e "$f" ] || continue
        base=$(basename "$f")
        _rs_rewrite_desktop "$box" "$f" "$RS_APPS_DIR/redsword-$box-$base"
        count=$((count+1))
    done

    # Copy icon themes so the launchers resolve their icons on the host.
    local theme
    for theme in hicolor Adwaita; do
        [ -d "$dir/usr/share/icons/$theme" ] || continue
        mkdir -p "$RS_ICONS_DIR/$theme"
        cp -a "$dir/usr/share/icons/$theme/." "$RS_ICONS_DIR/$theme/" 2>/dev/null || true
    done
    # Pixmap icons (many apps ship here).
    if [ -d "$dir/usr/share/pixmaps" ]; then
        mkdir -p "$RS_ICONS_DIR/../pixmaps" 2>/dev/null || true
        cp -a "$dir/usr/share/pixmaps/." /usr/share/pixmaps/ 2>/dev/null || true
    fi

    command -v update-desktop-database >/dev/null && update-desktop-database "$RS_APPS_DIR" 2>/dev/null || true
    command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -f "$RS_ICONS_DIR/hicolor" 2>/dev/null || true
    echo ">> exported $count app launcher(s) from '$box' to the RedSword menu"
}

# Remove every host launcher that came from a box (used on box removal / app removal).
rs_bridge_unexport(){
    local box=$1
    rm -f "$RS_APPS_DIR"/redsword-"$box"-*.desktop
    command -v update-desktop-database >/dev/null && update-desktop-database "$RS_APPS_DIR" 2>/dev/null || true
}

RS_BIN_DIR=${RS_BIN_DIR:-/usr/local/bin}

# Make the command-line tools from the named packages runnable directly on the host
# (e.g. after `redsword install --from kali nmap`, typing `nmap` just works).
# Only the given packages' own executables are exported, and never ones that would
# shadow a command the host already provides.
rs_bridge_export_cli(){
    local box=$1; shift
    mkdir -p "$RS_BIN_DIR"
    local pkg f cmd count=0
    for pkg in "$@"; do
        # Executables the package installs into the standard bin dirs, inside the box.
        while read -r f; do
            [ -n "$f" ] || continue
            rs_box_run "$box" test -f "$f" -a -x "$f" </dev/null 2>/dev/null || continue
            cmd=$(basename "$f")
            # Don't shadow a real host command, unless we already own that wrapper.
            if command -v "$cmd" >/dev/null 2>&1 && ! grep -qs "redsword-cli-wrapper" "$RS_BIN_DIR/$cmd"; then
                continue
            fi
            cat > "$RS_BIN_DIR/$cmd" <<EOF
#!/bin/sh
# redsword-cli-wrapper box=$box cmd=$cmd
exec /usr/libexec/redsword-run --cli $box $cmd "\$@"
EOF
            chmod +x "$RS_BIN_DIR/$cmd"
            count=$((count+1))
        done < <(rs_box_run "$box" bash -c "dpkg -L '$pkg' 2>/dev/null | grep -E '^/(usr/)?(s?bin|games)/'" 2>/dev/null || true)
    done
    [ "$count" -gt 0 ] && echo ">> exposed $count command(s) from '$box' on the RedSword terminal" || true
}

# Remove host command wrappers belonging to a box (all of them, or specific commands).
rs_bridge_unexport_cli(){
    local box=$1; shift
    local w
    if [ $# -gt 0 ]; then
        for w in "$@"; do
            [ -f "$RS_BIN_DIR/$w" ] && grep -qs "box=$box " "$RS_BIN_DIR/$w" && rm -f "$RS_BIN_DIR/$w"
        done
    else
        for w in "$RS_BIN_DIR"/*; do
            [ -f "$w" ] && grep -qs "redsword-cli-wrapper box=$box " "$w" && rm -f "$w"
        done
    fi
}
