// RedSword — "anonymous" browsing defaults for Firefox ESR.
// Installed to /etc/firefox-esr/redsword-anonymous.js. The third argument
// `locked` prevents the user (and sites) from changing these at runtime.
//
// Goal: Firefox opens straight into a private window, keeps no history,
// blocks trackers, and phones nothing home.

// --- Always private: no history, cache, or cookies kept between sessions ---
pref("browser.privatebrowsing.autostart", true, locked);

// --- Strict tracking / fingerprint / cryptominer protection ---
pref("browser.contentblocking.category", "strict");
pref("privacy.trackingprotection.enabled", true, locked);
pref("privacy.trackingprotection.pbmode.enabled", true, locked);
pref("privacy.trackingprotection.cryptomining.enabled", true, locked);
pref("privacy.trackingprotection.fingerprinting.enabled", true, locked);
pref("privacy.trackingprotection.socialtracking.enabled", true, locked);
pref("privacy.resistFingerprinting", true);
pref("privacy.donottrackheader.enabled", true);
pref("privacy.globalprivacycontrol.enabled", true);
// Reject known trackers and partition the rest (Total Cookie Protection).
pref("network.cookie.cookieBehavior", 5);

// --- No telemetry, studies, or data reporting ---
pref("toolkit.telemetry.enabled", false, locked);
pref("toolkit.telemetry.unified", false, locked);
pref("toolkit.telemetry.archive.enabled", false, locked);
pref("datareporting.healthreport.uploadEnabled", false, locked);
pref("datareporting.policy.dataSubmissionEnabled", false, locked);
pref("app.shield.optoutstudies.enabled", false, locked);
pref("app.normandy.enabled", false, locked);
pref("app.normandy.api_url", "");
pref("browser.newtabpage.activity-stream.feeds.telemetry", false);
pref("browser.newtabpage.activity-stream.telemetry", false);
pref("browser.ping-centre.telemetry", false);

// --- Don't nag, don't remember logins/forms (anonymous) ---
pref("extensions.pocket.enabled", false, locked);
pref("browser.formfill.enable", false);
pref("signon.rememberSignons", false);
pref("browser.shell.checkDefaultBrowser", false);
pref("browser.aboutConfig.showWarning", false);
